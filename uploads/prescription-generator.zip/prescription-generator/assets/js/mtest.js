const mtestData = {
    "mtest": [
        [
            "X-Ray: Elbow Joint (Both)",
            "218"
        ],
        [
            "Mammography Left Breast",
            "422"
        ],
        [
            "Mammography Right Breast",
            "421"
        ],
        [
            "MCH",
            "420"
        ],
        [
            "MCHC",
            "419"
        ],
        [
            "MCU (X-Ray Contrast)",
            "418"
        ],
        [
            "MCV",
            "417"
        ],
        [
            "Methacholine Challenge Test",
            "416"
        ],
        [
            "Microfilaria",
            "415"
        ],
        [
            "Monospot Test for IM",
            "414"
        ],
        [
            "MRI Ankle Joint (Both)",
            "413"
        ],
        [
            "Anti H. Pylori IgG",
            "412"
        ],
        [
            "MRI Ankle Joint (Left)",
            "411"
        ],
        [
            "MRI Ankle Joint (Right)",
            "410"
        ],
        [
            "MRI Chest",
            "409"
        ],
        [
            "MRI Elbow Joint (Both)",
            "408"
        ],
        [
            "MRI Elbow Joint (Left)",
            "407"
        ],
        [
            "MRI Elbow Joint (Right)",
            "406"
        ],
        [
            "MRI Head",
            "405"
        ],
        [
            "MRI Hip Joint (Both)",
            "404"
        ],
        [
            "MRI Hip Joint (Left)",
            "403"
        ],
        [
            "MRI Hip Joint (Right)",
            "402"
        ],
        [
            "Anti Herpes Simplex (1&2) IgG/IgM",
            "401"
        ],
        [
            "MRI Knee Joint",
            "400"
        ],
        [
            "MRI Knee Joint (Left)",
            "399"
        ],
        [
            "MRI Knee Joint (Right)",
            "398"
        ],
        [
            "MRI Neck",
            "397"
        ],
        [
            "MRI Pelvic",
            "396"
        ],
        [
            "MRI Shoulder Joint (Both)",
            "395"
        ],
        [
            "MRI Shoulder Joint (Left)",
            "394"
        ],
        [
            "MRI Shoulder Joint (Right)",
            "393"
        ],
        [
            "MRI Wrist Joint (Both)",
            "392"
        ],
        [
            "MRI Wrist Joint (Left)",
            "391"
        ],
        [
            "Anti HIV (1&2)",
            "390"
        ],
        [
            "MRI Wrist Joint (Right)",
            "389"
        ],
        [
            "MT (Mantoux Test)",
            "388"
        ],
        [
            "MTB-PCR (Qualitative)",
            "387"
        ],
        [
            "Myelography Cervical",
            "386"
        ],
        [
            "Myelography Full",
            "385"
        ],
        [
            "Myelography Lumber",
            "384"
        ],
        [
            "Myelography Lumbo-Dorsal",
            "383"
        ],
        [
            "O.C.G (X-Ray Contrast)",
            "378"
        ],
        [
            "RGU (X-Ray Contrast)",
            "332"
        ],
        [
            "X-Ray: Abdomen (Erect/Supine)",
            "226"
        ],
        [
            "X-Ray: Ankle Joint (Both)",
            "225"
        ],
        [
            "X-Ray: Ankle Joint (Left) : A/P, Oblique, Lateral",
            "224"
        ],
        [
            "X-Ray: Ankle Joint (Right) : A/P, Oblique, Lateral",
            "223"
        ],
        [
            "X-Ray: Cervical Spine : A/P, Lateral, Oblique",
            "222"
        ],
        [
            "X-Ray: Chest: P/A, A/P, Apical, Oblique Lateral",
            "221"
        ],
        [
            "X-Ray: Coccyx Joints, A/P, Lateral",
            "220"
        ],
        [
            "X-Ray: Dorsal Spine : A/P, Lateral, Oblique",
            "219"
        ],
        [
            "Sputum for malignant cell",
            "212"
        ],
        [
            "Stool: C/S, Parasite",
            "50"
        ],
        [
            "Stool R/M/E, OBT, Reducing Substances",
            "51"
        ],
        [
            "ASO Titre",
            "52"
        ],
        [
            "Sputum: C/S, Gram Stain, AFB Stain",
            "53"
        ],
        [
            "Serum Vitamin B12",
            "54"
        ],
        [
            "Semen Analysis",
            "55"
        ],
        [
            "S. Uric Acid",
            "56"
        ],
        [
            "S. Total Protein",
            "57"
        ],
        [
            "S. Phosphate",
            "58"
        ],
        [
            "S. Lipase",
            "59"
        ],
        [
            "S. Iron",
            "60"
        ],
        [
            "S. Folate",
            "61"
        ],
        [
            "S. Electrolyte",
            "62"
        ],
        [
            "S. Creatinine",
            "63"
        ],
        [
            "S. Cholesterol",
            "64"
        ],
        [
            "S. Calcium",
            "65"
        ],
        [
            "S. Bilirubin Total",
            "66"
        ],
        [
            "S. Bilirubin Direct/Indirect",
            "67"
        ],
        [
            "APTT",
            "68"
        ],
        [
            "S. Amylase",
            "69"
        ],
        [
            "S. Acid Phosphatase",
            "70"
        ],
        [
            "Rose - Waaler Test",
            "71"
        ],
        [
            "Rh - Antibody Titre",
            "72"
        ],
        [
            "Reticulocyte Count",
            "73"
        ],
        [
            "Anti-Toxoplasma IgG/IgM",
            "74"
        ],
        [
            "PSA (Total)",
            "75"
        ],
        [
            "PSA (Free)",
            "76"
        ],
        [
            "Prostatic Smear: Gram Stain, C/S",
            "77"
        ],
        [
            "Prolactin",
            "78"
        ],
        [
            "Anti-Thyroid Ab",
            "79"
        ],
        [
            "Progesterone",
            "80"
        ],
        [
            "Anti-Rubella IgG/IgM",
            "81"
        ],
        [
            "Platelet Count",
            "82"
        ],
        [
            "Plasma Fibrinogen",
            "83"
        ],
        [
            "Anti-HBs (HbsAb)",
            "84"
        ],
        [
            "ANA",
            "85"
        ],
        [
            "PCV",
            "86"
        ],
        [
            "Opiates",
            "87"
        ],
        [
            "Anti-DNA",
            "88"
        ],
        [
            "Myoglobin",
            "89"
        ],
        [
            "Malarial Parasite",
            "90"
        ],
        [
            "Lithium",
            "91"
        ],
        [
            "Lipid Profile: Cholesterol/HDL/LDL/Triglyceride",
            "92"
        ],
        [
            "LH",
            "93"
        ],
        [
            "LE Cell Preparation",
            "94"
        ],
        [
            "LDH",
            "95"
        ],
        [
            "Anti Dengue IgG/IgM",
            "96"
        ],
        [
            "ICT for Kala-Azar (Ag/Ab)",
            "97"
        ],

        [
            "ICT for Filaria",
            "98"
        ],
        [
            "ICT - TB",
            "99"
        ],
        [
            "Homocystine",
            "100"
        ],
        [
            "HBsAg (Screening)",
            "101"
        ],
        [
            "HBsAg (Elisa)",
            "102"
        ],
        [
            "HBeAg",
            "103"
        ],
        [
            "HbA1C",
            "104"
        ],
        [
            "Protein electrophoresis",
            "105"
        ],
        [
            "Hb - Electrophoresis",
            "106"
        ],
        [
            "Growth Hormone",
            "107"
        ],
        [
            "FSH",
            "108"
        ],
        [
            "S. Ferritin",
            "109"
        ],
        [
            "FDP",
            "110"
        ],
        [
            "ALT (SGPT)",
            "111"
        ],
        [
            "s. triglyceride",
            "112"
        ],
        [
            "CE count",
            "113"
        ],
        [
            "CBC with blood film",
            "114"
        ],
        [
            "Blood film (pbf)",
            "115"
        ],
        [
            "HCT",
            "116"
        ],
        [
            "Fasting Blood Sugar with CUS",
            "117"
        ],
        [
            "Random Blood Sugar with CUS",
            "118"
        ],
        [
            "2hrs ABF (after breakfast)",
            "119"
        ],
        [
            "S. albumin",
            "120"
        ],
        [
            "S. globulin",
            "121"
        ],
        [
            "AG ratio",
            "122"
        ],
        [
            "yGT",
            "123"
        ],
        [
            "urinary amylase",
            "124"
        ],
        [
            "2hrs after 75gm glucose",
            "125"
        ],
        [
            "OGIT",
            "126"
        ]
    ]}