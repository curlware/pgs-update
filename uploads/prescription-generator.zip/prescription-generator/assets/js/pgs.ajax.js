jQuery(document).ready(function($) {

    $('.showFormBtn').on('click', function() {
       // Get the doctorId value from the button's data attribute
       var doctorId = $(this).data('doctor-id');
       var doctorName = $(this).data('doctor-name');

       // Load the phone number input form with the doctorId hidden field
       $.ajax({
           type: 'POST',
           url: ajax_object.ajax_url,
           data: {
               action: 'get_phone_number_form',
               doctor_id: doctorId, // Pass the doctorId to the server
               doctor_name: doctorName,
           },
           success: function(response) {
               $('#formContainer').html(response);
               
                
            }
        });
    });



   // Submit phone number form via AJAX
   $(document).on('submit', '#phoneNumberForm', function(e) {
    e.preventDefault();

    // Get the entered mobile number
    var mobileNumber = $('#mobileNumber').val();
    var doctorId = $('#doctorId').val();
    var doctorName = $('#doctorName').val();
    var time = $('#time').val();
    var date = $('#datepicker').val();
    var pgsnonce = $('#pgsnonce').val();
    // AJAX to check if mobile number is available
        $.ajax({
            type: 'POST',
            url: ajax_object.ajax_url,
            data: {
                action: 'check_mobile_availability',
                mobile_number: mobileNumber,
                doctor_id: doctorId,
                doctor_name: doctorName,
                doctor_time: time,
                doctor_date: date,
                pgs_nonce: pgsnonce,
            },
            success: function(response) {
                // Load the appropriate form based on availability
                $('#formContainer').html(response);
            }
        });
    });

    $(document).on('click', '.appointconfirm', function(e) {
        e.preventDefault();
        var doctorId = $(this).data('doctor-id');
        var doctorName = $(this).data('doctor-name');
        var doctorTime = $(this).data('doctor-time');
        var doctorDate = $(this).data('doctor-date');
        var patientId = $(this).data('patient-id');
        var patientName = $(this).data('patient-name');
        var patientMobile = $(this).data('patient-mobile');
        // AJAX to check if mobile number is available
        $.ajax({
            type: 'POST',
            url: ajax_object.ajax_url,
            data: {
                action: 'submit_confirm_appointment',
                patient_id: patientId,
                patient_name: patientName,
                patient_mobile: patientMobile,
                doctor_id: doctorId,
                doctor_name: doctorName,
                doctor_time: doctorTime,
                doctor_date: doctorDate,
            },
            success: function(response) {
                // Load the appropriate form based on availability
                $('#formContainer').html(response);
            }
        });
    });

    $(document).on('submit', '#newappointconfirm', function(e) {
        e.preventDefault();
           // Get the entered mobile number
            
            var doctorId = $('#doctorId').val();
            var doctorName = $('#doctorName').val();
            var doctorTime = $('#doctorTime').val();
            var doctorDate = $('#doctorDate').val();
            var patientName = $('#patientName').val();
            var patientMobile = $('#patientMobile').val();
            var patientAge = $('#patientAge').val();
            var patientAddress = $('#patientAddress').val();
            var patientMaritalstatus = $('#patientMaritalstatus').val();
            var patientGender = $('#patientGender').val();
            var patientBloodGroup = $('#patientBloodGroup').val();
            var patientWeight = $('#patientWeight').val();
            var patientHeight = $('#patientHeight').val();
            
        // AJAX to check if mobile number is available
        $.ajax({
            type: 'POST',
            url: ajax_object.ajax_url,
            data: {
                action: 'submit_confirm_newappointment',
                doctor_id: doctorId,
                doctor_name: doctorName,
                doctor_date: doctorDate,
                doctor_time: doctorTime,
                patient_name: patientName,
                patient_mobile: patientMobile,
                patient_age: patientAge,
                patient_address: patientAddress,
                patient_marital_status: patientMaritalstatus,
                patient_gender: patientGender,
                patient_blood: patientBloodGroup,
                patient_weight: patientWeight,
                patient_height: patientHeight,
                
            },
            success: function(response) {
                // Load the appropriate form based on availability
                $('#formContainer').html(response);
            }
        });
    });

});
