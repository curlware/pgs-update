<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
function pgs_side_bar_function(){
  // Check if the user is logged in and has the manager role
  if (is_user_logged_in() && current_user_can('doctor') || current_user_can('administrator')) {
    $user_id = get_current_user_id();
    // Display links based on user role
 echo '<style>.nav-item{list-style: none;
    
    border: 1px solid #dddddd;
    border-bottom-width: 0;}.nav-item:last-child {
        border-bottom-width: 1px;}
        .nav-item .nav-link{text-decoration: none !important;}
        </style>';
        echo ' <nav class="navbar navbar-expand-lg navbar-light bg-light">
       
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
       
        <div class="collapse navbar-collapse" id="navbarSupportedContent">';
 echo '<div class="nav nav-pills  no flex-column br-1">';
 echo '<li class="nav-item"><a class="nav-link   text-uppercase ' . (strpos($_SERVER['REQUEST_URI'], '/pgs-dashboard') !== false ? 'active' : '') . '" href="' . site_url('/pgs-dashboard') . '"><span class="dashicons dashicons-chart-pie"></span>&nbsp;&nbsp;PGS Dashboard</a></li>';
 echo '<li class="nav-item"><a class="nav-link   text-uppercase ' . (strpos($_SERVER['REQUEST_URI'], '/new-prescription') !== false ? 'active' : '') . '" href="' . site_url('/new-prescription') . '"><span class="dashicons dashicons-editor-paste-word"></span>&nbsp;&nbsp; New Prescription</a></li>';  
 echo '<li class="nav-item"><a class="nav-link   text-uppercase ' . (strpos($_SERVER['REQUEST_URI'], '/prescription-list') !== false ? 'active' : '') . '" href="' . site_url('/prescription-list') . '"><span class="dashicons dashicons-table-col-after"></span>&nbsp;&nbsp; Prescription List</a></li>';
 echo '<li class="nav-item"><a class="nav-link   text-uppercase ' . (strpos($_SERVER['REQUEST_URI'], '/prescription-print') !== false ? 'active' : '') . '" href="' . site_url('/prescription-print') . '"><span class="dashicons dashicons-printer"></span>&nbsp;&nbsp; Prescription Print</a></li>';
 echo '<li class="nav-item"><a class="nav-link   text-uppercase ' . (strpos($_SERVER['REQUEST_URI'], '/patient-list') !== false ? 'active' : '') . '" href="' . site_url('/patient-list') . '"><span class="dashicons dashicons-list-view"></span>&nbsp;&nbsp; Patient List</a></li>';  
 echo '<li class="nav-item"><a class="nav-link   text-uppercase ' . (strpos($_SERVER['REQUEST_URI'], '/patient-add') !== false ? 'active' : '') . '" href="' . site_url('/patient-add') . '"><span class="dashicons dashicons-admin-users"></span>&nbsp;&nbsp; Patient Add</a></li>';
 echo '<li class="nav-item"><a class="nav-link   text-uppercase ' . (strpos($_SERVER['REQUEST_URI'], '/appointment-list') !== false ? 'active' : '') . '" href="' . site_url('/appointment-list') . '"><span class="dashicons dashicons-media-spreadsheet"></span>&nbsp;&nbsp; Appointment List</a></li>';
 echo '<li class="nav-item"><a class="nav-link   text-uppercase ' . (strpos($_SERVER['REQUEST_URI'], '/appointment-form') !== false ? 'active' : '') . '" href="' . site_url('/appointment-form') . '"><span class="dashicons dashicons-calendar-alt"></span>&nbsp;&nbsp; Appointment Form</a></li>';
 echo '<li class="nav-item"><a class="nav-link   text-uppercase ' . (strpos($_SERVER['REQUEST_URI'], '/appointment-setting') !== false ? 'active' : '') . '" href="' . site_url('/appointment-setting') . '"><span class="dashicons dashicons-admin-settings"></span>&nbsp;&nbsp; Appointment Setting</a></li>';
 echo '<li class="nav-item"><a class="nav-link   text-uppercase ' . (strpos($_SERVER['REQUEST_URI'], '/pgs-profile') !== false ? 'active' : '') . '" href="' . site_url('/pgs-profile') . '"><span class="dashicons dashicons-businessman"></span>&nbsp;&nbsp;Profile</a></li>';
 echo '<li class="nav-item"><a class="nav-link   text-uppercase" href="' . wp_logout_url('pgs-login') . '"><span class="dashicons dashicons-migrate"></span>&nbsp;&nbsp; Log Out</a></li>';
 echo '</div></div></nav>';

} elseif (is_user_logged_in() && current_user_can('assistant')) {
    $user_id = get_current_user_id();
     // Display links based on user role
     echo '<style>.nav-item{list-style: none;
    
        border: 1px solid #dddddd;
        border-bottom-width: 0;}.nav-item:last-child {
            border-bottom-width: 1px;}
            .nav-item .nav-link{text-decoration: none !important;}
            </style>';
            echo ' <nav class="navbar navbar-expand-lg navbar-light bg-light">
           
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
           
            <div class="collapse navbar-collapse" id="navbarSupportedContent">';
 echo '<div class="nav nav-pills   flex-column br-1">';
 echo '<li class="nav-item"><a class="nav-link   text-uppercase ' . (strpos($_SERVER['REQUEST_URI'], '/pgs-dashboard') !== false ? 'active' : '') . '" href="' . site_url('/pgs-dashboard') . '"><span class="dashicons dashicons-chart-pie"></span>&nbsp;&nbsp;PGS Dashboard</a></li>';
 echo '<li class="nav-item"><a class="nav-link   text-uppercase ' . (strpos($_SERVER['REQUEST_URI'], '/prescription-list') !== false ? 'active' : '') . '" href="' . site_url('/prescription-list') . '"><span class="dashicons dashicons-table-col-after"></span>&nbsp;&nbsp; Prescription List</a></li>';
 echo '<li class="nav-item"><a class="nav-link   text-uppercase ' . (strpos($_SERVER['REQUEST_URI'], '/prescription-print') !== false ? 'active' : '') . '" href="' . site_url('/prescription-print') . '"><span class="dashicons dashicons-printer"></span>&nbsp;&nbsp; Prescription Print</a></li>';
 echo '<li class="nav-item"><a class="nav-link   text-uppercase ' . (strpos($_SERVER['REQUEST_URI'], '/patient-list') !== false ? 'active' : '') . '" href="' . site_url('/patient-list') . '"><span class="dashicons dashicons-list-view"></span>&nbsp;&nbsp; Patient List</a></li>';  
 echo '<li class="nav-item"><a class="nav-link   text-uppercase ' . (strpos($_SERVER['REQUEST_URI'], '/patient-add') !== false ? 'active' : '') . '" href="' . site_url('/patient-add') . '"><span class="dashicons dashicons-admin-users"></span>&nbsp;&nbsp; Patient Add</a></li>';
 echo '<li class="nav-item"><a class="nav-link   text-uppercase ' . (strpos($_SERVER['REQUEST_URI'], '/appointment-list') !== false ? 'active' : '') . '" href="' . site_url('/appointment-list') . '"><span class="dashicons dashicons-media-spreadsheet"></span>&nbsp;&nbsp; Appointment List</a></li>';
 echo '<li class="nav-item"><a class="nav-link   text-uppercase ' . (strpos($_SERVER['REQUEST_URI'], '/appointment-form') !== false ? 'active' : '') . '" href="' . site_url('/appointment-form') . '"><span class="dashicons dashicons-calendar-alt"></span>&nbsp;&nbsp; Appointment Form</a></li>';
 echo '<li class="nav-item"><a class="nav-link   text-uppercase ' . (strpos($_SERVER['REQUEST_URI'], '/pgs-profile') !== false ? 'active' : '') . '" href="' . site_url('/pgs-profile') . '"><span class="dashicons dashicons-businessman"></span>&nbsp;&nbsp;Profile</a></li>';
 echo '<li class="nav-item"><a class="nav-link   text-uppercase" href="' . wp_logout_url('pgs-login') . '"><span class="dashicons dashicons-migrate"></span>&nbsp;&nbsp; Log Out</a></li>';
 echo '</div></div></nav>';
}

else {
    // If the user is not a manager, display an error message
    echo '<p class="error-message">You have not permission to access this page.</p>';
}





}
