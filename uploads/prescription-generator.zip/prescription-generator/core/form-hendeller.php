<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
 // Generate prescription text (customize as needed)
 function pgs_prescription_form_submission() {
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['newprescription']) && isset($_POST['patient_name'])) {
        // Process the prescription form data
        
        
        $dosagedcrp= $_POST["dosagedcrp"];
        $frequencies = $_POST["frequency"];
        $medicationNames = $_POST["medication_name"];
        $dosages = $_POST["dosage"];
        $patient = $_POST["patient_name"];
        $age= $_POST["patient_age"];
        $gender = $_POST["patient_gender"];
        $weight = $_POST["patient_weight"];
        $height = $_POST["patient_height"];
        $clinicalcase = $_POST["clinicalcase"];
        $phone = $_POST["patient_mobile"];
        $address = $_POST["patient_address"];
        $blood_group = $_POST["blood_group"];
        $bp = ($_POST["bp"] !== '') ? 'BP :'.$_POST["bp"] : '' ;
        $pulse = ($_POST["pulse"] !== '') ? 'Pulse :'.$_POST["pulse"] : '' ;
        $spo2 = ($_POST["spo2"] !== '') ? 'Spo2 :'.$_POST["spo2"] : '' ;
        $anaemia = ($_POST["anaemia"] !== '') ? 'Anaemia :'.$_POST["anaemia"] : '' ;
        $jaubdice = ($_POST["jaubdice"] !== '') ? 'Jaubdice :'.$_POST["jaubdice"] : '' ;
        $etc = ($_POST["etc"] !== '') ? 'Others :'.$_POST["etc"] : '' ;
        $oe="" ;
        $date=date("d-m-Y");
        $patient_id=$_POST['patient_id'];
        $current_user = wp_get_current_user();

        // Check if the user is logged in
        if ( $current_user->ID != 0 ) {
            // Display the email address of the currently logged-in user
            $doctor_email= $current_user->user_email;
            $doctor_id = get_current_user_id();
            $doctor_name= $current_user->display_name;
        } else { $doctor_email='';}

       // $doctor_name = 'jon';
        //$doctor_id ='1';
        if($image_url !==''):
            $doctor_logo='<img style=" width:80px; height:80px;"src="'.$image_url.'" alt="Selected Image">'; else: $doctor_logo='';endif; 

        // TODO: Add your logic to handle the prescription data, such as storing it in a database or generating a PDF.
        
        // Example: Print the prescription data
        echo "<h2>Generated Prescription:</h2>";
        for ($i = 0; $i < count($medicationNames); $i++) {
            $nu= $i+1;
            $prescription_text .= "<ol  start='{$nu}'><li>{$medicationNames[$i]}</li><br>{$dosages[$i]} &nbsp;&nbsp; ( {$frequencies[$i]})&nbsp;&nbsp; {$dosagedcrp[$i]} </ol>";
        }
   

     $clinicalreport= json_encode(array(
        'cc' => $clinicalcase,
        'bp' => $bp,
        'pulse' => $pulse,
        'spo2' =>  $spo2,
        'anaemia' => $anaemia,
        'jaubdice' => $jaubdice,
        'etc' => $etc,
     ));

        global $wpdb;
        if($patient_id===''){
            $wpdb->insert(
                'wp_as_patient',
                array(
                    'patient_name' => $patient,
                    'blood_group' => $blood_group,
                    'patient_address' => $address,
                    'patient_mobile' => $phone,
                    'patient_age' => $age,
                    'patient_weight' => $weight,
                    'patient_height' => $height,
                    'patient_gender' => $gender,
                )
            );

            $last_insert_id = $wpdb->insert_id;
            $pendin_exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM wp_as_appointments WHERE doctor_id = %d AND patient_id = %d AND appoint_status = %s", $doctor_id, $last_insert_id, 'pending'));
            if($pendin_exists > 0){ $wpdb->get_results($wpdb->prepare("UPDATE `wp_as_appointments` SET `appoint_status` = 'complete' WHERE  doctor_id = %d AND patient_id = %d AND appoint_status = %s", $doctor_id, $last_insert_id, 'pending'));}
            $wpdb->insert(
                'wp_as_pescription',
                array(
                    'doctor_id' => $doctor_id,
                    'doctor_email' => $doctor_email,
                    'doctor_name' => $doctor_name,
                    'patient_id' => $last_insert_id,
                    'patient_name' => $patient,
                    'patient_mobile' => $phone,
                    'medicine' => $prescription_text,
                    'clinicalreport' => $clinicalreport,
                )
            );
            $last_prescription_id = $wpdb->insert_id;
        }else{  
            
            $pendin_exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM wp_as_appointments WHERE doctor_id = %d AND patient_id = %d AND appoint_status = %s", $doctor_id, $patient_id, 'pending'));
            if($pendin_exists > 0){ $wpdb->get_results($wpdb->prepare("UPDATE `wp_as_appointments` SET `appoint_status` = 'complete' WHERE  doctor_id = %d AND patient_id = %d AND appoint_status = %s", $doctor_id, $patient_id, 'pending'));}
            
            $wpdb->insert(
            'wp_as_pescription',
            array(
                'doctor_id' => $doctor_id,
                'doctor_email' => $doctor_email,
                'doctor_name' => $doctor_name,
                'patient_id' => $patient_id,
                'patient_name' => $patient,
                'patient_mobile' => $phone,
                'medicine' => $prescription_text,
                'clinicalreport' => $clinicalreport,
            )
        );
        $last_prescription_id = $wpdb->insert_id;
    }

        $prescription_print_url= 'prescription-print/?page=prescription-print&printid='. $last_prescription_id;
        // Redirect to the prescription post
        wp_redirect(site_url( $prescription_print_url ));
        exit;
    }
}

?>