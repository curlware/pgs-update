<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
function pgs_create_tables() {
    global $wpdb;

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE `wp_as_appointments` (
                `id` mediumint(9) NOT NULL AUTO_INCREMENT,
                `doctor_id` mediumint(9) NOT NULL,
                `doctor_name` varchar(255) NOT NULL,
                `patient_id` int(11) NOT NULL,
                `patient_name` varchar(255) NOT NULL,
                `patient_mobile` varchar(20) NOT NULL,
                `appointment_date` date NOT NULL DEFAULT current_timestamp(),
                `appointment_time` varchar(255) NOT NULL,
                `appoint_status` varchar(20) NOT NULL DEFAULT 'pending',
                `appointment_daily_id` int(11) NOT NULL,
                PRIMARY KEY (`id`)
                ) $charset_collate;
            CREATE TABLE `wp_as_schedule` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `doctor_id` int(11) NOT NULL,
                `appointment_day` varchar(255) NOT NULL,
                `appointment_time` varchar(255) NOT NULL,
                PRIMARY KEY  (id)
                ) $charset_collate;
            CREATE TABLE `wp_as_doctor` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `doctor_name` varchar(255) NOT NULL,
                `doctor_degree` varchar(255) NOT NULL,
                `doctor_address` varchar(255) NOT NULL,
                `doctor_specialist` varchar(255) NOT NULL,
                `doctor_appoint_details` varchar(255) NOT NULL,
                `doctor_id` varchar(255) NOT NULL,
                `doctor_email` varchar(255) NOT NULL,
                `appoint_status` varchar(255) NOT NULL,
                `doctor_profile_image_url` varchar(255) NOT NULL,
                `assistant_id` int(11) NOT NULL,
                `prescription_form_details` varchar(2555) NOT NULL,
                PRIMARY KEY  (id)
                ) $charset_collate;
            CREATE TABLE `wp_as_patient` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `patient_name` varchar(255) NOT NULL,
                `blood_group` varchar(255) NOT NULL,
                `patient_gender` varchar(11) NOT NULL,
                `patient_address` varchar(255) NOT NULL,
                `patient_mobile` varchar(255) NOT NULL,
                `patient_age` int(11) NOT NULL,
                `patient_weight` int(11) NOT NULL,
                `patient_height` varchar(255) NOT NULL,
                `patient_history` text NOT NULL,
                `patient_email` varchar(255) NOT NULL,
                `patient_marital_status` varchar(255) NOT NULL,
                PRIMARY KEY  (id)
                ) $charset_collate AUTO_INCREMENT=10001;
            CREATE TABLE `wp_as_pescription` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `doctor_id` int(255) NOT NULL,
                `doctor_email` varchar(255) NOT NULL,
                `doctor_name` varchar(255) NOT NULL,
                `patient_id` int(255) NOT NULL,
                `patient_name` varchar(255) NOT NULL,
                `patient_mobile` varchar(15) NOT NULL,
                `medicine` longtext NOT NULL,
                `clinicalreport` mediumtext NOT NULL,
                `date` date NOT NULL DEFAULT current_timestamp(),
                PRIMARY KEY  (id)
                ) $charset_collate;
    ";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
