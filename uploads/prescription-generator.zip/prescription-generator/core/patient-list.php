<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
function patient_list_page(){    
    
    ?>

<div class="row" >
    <div class="sidebar col-lg-3 col-sm-12" >
    <?php pgs_side_bar_function();?>
    </div>
    <div class="col-lg-9 col-sm-12  overflow-auto ">
        <table id="patientlist" class="display table table-striped table-bordered" >
            <thead>
                <tr>
                    <th>Patient Name</th>
                    <th>Patient Id</th>
                    <th>Mobile</th>
                    <th>Blood Group</th>
                    <th>Age</th>
                    <th>Address</th>
                    <th>Details</th>
                </tr>
            </thead>
            
            <tfoot>
                <tr>
                    <th>Patient Name</th>
                    <th>Patient Id</th>
                    <th>Mobile</th>
                    <th>Blood Group</th>
                    <th>Age</th>
                    <th>Address</th>
                    <th>Details</th>
                </tr>
            </tfoot>
        </table>
    </div>
</div>

    <script>
    
//     new DataTable('#patientList', {
 
//  buttons: [
//      'copy', 'excel', 'pdf'
//  ],

// });

jQuery(document).ready(function($) {
    // AJAX for patient list
    $.ajax({
        type: 'POST',
        url: ajax_object.ajax_url,
        data: { 
            action: 'get_patient_list',
            pgs_nonce: ajax_object.pgs_nonce, // Pass the nonce to the server
            },
        
        
        
        dataType: 'json', // Specify that the response is in JSON format
        success: function(response) {
            // Initialize DataTables with the fetched data
            $('#patientlist').DataTable({
                data: response,
                columns: [
                    { data: 'patient_name' },
                    { data: 'id' },
                    { data: 'patient_mobile' },
                    { data: 'blood_group' },
                    { data: 'patient_age' },
                    { data: 'patient_address' },
                    { data: 'edit_link' },
                ]
            });
        }
    });
});


</script>
    <?php
    }


    add_action('wp_ajax_get_patient_list', 'get_patient_list');
    add_action('wp_ajax_nopriv_get_patient_list', 'get_patient_list');
    
    function get_patient_list() {
        if (isset($_POST['pgs_nonce']) && wp_verify_nonce($_POST['pgs_nonce'], 'pgs_nonce_action')) {
    
        global $wpdb;
    
        $patientedit = site_url('/patient-add/?patientid=');
    
        $prescription_data = $wpdb->get_results("SELECT patient_name, id, patient_mobile, blood_group, patient_age, patient_address FROM wp_as_patient");
    
        $output = array();
    
        foreach ($prescription_data as $data) {
            $output[] = array(
                'patient_name' => $data->patient_name,
                'id' => $data->id,
                'patient_mobile' => $data->patient_mobile,
                'blood_group' => $data->blood_group,
                'patient_age' => $data->patient_age,
                'patient_address' => $data->patient_address,
                'edit_link' => '<a href="' . $patientedit . $data->id . '">Edit</a>',
            );
        }
    
        wp_send_json($output);
    }else {
        // Nonce verification failed
        wp_send_json_error('Nonce verification failed.');
    }
        // Always exit after processing AJAX
        wp_die();
    }
      