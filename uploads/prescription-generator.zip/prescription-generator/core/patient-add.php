<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
function patient_add_page(){
   
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['patientid']) && $_GET['patientid'] !=='') {
        $patient_id = sanitize_text_field($_GET['patientid']);
        global $wpdb;
        $patient_details = $wpdb->get_row("SELECT * FROM wp_as_patient WHERE id = '$patient_id'");
      
        }   
        if (isset($patient_details) && !empty($patient_details)) {
            $patient_id=$patient_details->id;
            $patient_name=$patient_details->patient_name;
            $blood_group=$patient_details->blood_group;
            $patient_gender=$patient_details->patient_gender;
            $patient_address=$patient_details->patient_address;
            $patient_mobile=$patient_details->patient_mobile;
            $patient_age=$patient_details->patient_age;
            $patient_weight=$patient_details->patient_weight;
            $patient_height=$patient_details->patient_height;
            $patient_email=$patient_details->patient_email;
            $patient_history=$patient_details->patient_history;
            $patient_marital_status=$patient_details->patient_marital_status;
            
        }else{ 
            $patient_id='';
            $patient_name='';
            $blood_group='';
            $patient_gender='';
            $patient_address='';
            $patient_mobile='';
            $patient_age='';
            $patient_marital_status='';
            $patient_weight='';
            $patient_height='';
            $patient_email='';
            $patient_history='';
        }






 
    


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['patientadd']) && isset($_POST['patient_name'])) {  
        global $wpdb;
        
        $patient_name =$_POST['patient_name'] !=='' ? $_POST['patient_name'] : '';
        $patient_email =$_POST['patient_email'] !=='' ? $_POST['patient_email'] : '';
        $patient_mobile =$_POST['patient_mobile'] !=='' ? $_POST['patient_mobile'] : '';
        $patient_age =$_POST['patient_age'] !=='' ? $_POST['patient_age'] : '';
        $patient_marital_status =$_POST['patient_marital_status'] !=='' ? $_POST['patient_marital_status'] : '';
        $patient_gender =$_POST['patient_gender'] !=='' ? $_POST['patient_gender'] : '';
        $blood_group =$_POST['blood_group'] !=='' ? $_POST['blood_group'] : '';
        $patient_weight =$_POST['patient_weight'] !=='' ? $_POST['patient_weight'] : '';
        $patient_height =$_POST['patient_height'] !=='' ? $_POST['patient_height'] : '';
        $patient_address =$_POST['patient_address'] !=='' ? $_POST['patient_address'] : '';
        $patient_history =$_POST['patient_history'] !=='' ? $_POST['patient_history'] : '';
        
        $data = array(
            'patient_name' => $patient_name,
            'patient_email' => $patient_email,
            'patient_mobile' => $patient_mobile,
            'patient_age' => $patient_age,
            'patient_marital_status' => $patient_marital_status,
            'patient_gender' => $patient_gender,
            'blood_group' => $blood_group,
            'patient_weight' => $patient_weight,
            'patient_height' => $patient_height,
            'patient_address' =>  $patient_address ,
            'patient_history' =>   $patient_history,
        );
        if (isset($_POST['patient_id'])) {
            $patient_id = sanitize_text_field($_POST['patient_id']);
            $where = array('id' => $patient_id);
            $table_name = 'wp_as_patient';
            $updatepatient= $wpdb->update($table_name, $data, $where);
              
                if ($updatepatient === false) {
                        // Update failed
                        
                        echo'<div class="alert alert-danger" role="alert">
                        User Update not success.
                    </div>';
                    } else {
                        // Update successful
                        echo'<div class="alert alert-success" role="alert">
                        User Update success.
                    </div>';
                    }
        }else{
            $addpatient=$wpdb->insert(
                'wp_as_patient',
                $data
            );
            
    if($addpatient  === false){echo'<div class="alert alert-danger" role="alert">
        User add not success.
      </div>';}else{echo'<div class="alert alert-success" role="alert">
        User add success.
      </div>';}
        
    }


        }
    

    
    ?>

<div class="row" >
        <div class="sidebar col-lg-3 col-sm-12" >
            <?php pgs_side_bar_function();?>
        </div>
        <div class="col-lg-9 col-sm-12">
            <div class="card ">
                <div class="card-header">
                    <h4 class="card-title">Patient Information</h4>
                </div>
                <div class="card-body">
                    <div class="basic-form">
                        <form method="post" >
                            <div class="row">
                             <?php if(isset($_GET['patientid'])){ echo '<input type="hidden" value="'.$_GET['patientid'].'" name="patient_id">' ;}?>
                                <div class="col-xl-6">
                                    <div class="form-group">
                                        <label>Patient Name</label>
                                        <input name="patient_name"type="text"value="<?php _e($patient_name)?>" class="form-control" placeholder="Patient Full Name"required>
                                    </div>             
                                    <div class="form-group">
                                        <label>Patient Email</label>
                                        <input name="patient_email" value="<?php _e($patient_email)?>" type="email" class="form-control" placeholder="Email">
                                    </div>
                                    <div class="form-group">
                                        <label>Patient Mobile</label>
                                        <input name="patient_mobile" value="<?php _e($patient_mobile)?>" type="text" class="form-control" placeholder="Mobile No." required>
                                    </div>
                                    <div class="form-group">
                                        <label>Patient Age</label>
                                        <input name="patient_age" value="<?php _e($patient_age)?>" type="text" class="form-control" placeholder="Age" required>
                                    </div>
                                </div>
                                <div class="col-xl-6">                                    
                                    <div class="form-group">
                                    <label>Marital status </label>
                                        <select name="patient_marital_status" class="form-control form-select">
                                        <?php if ($patient_marital_status !==''){echo '<option value="'._e($patient_marital_status).'" selected>'.$patient_marital_status.'</option>'; }?>
                                            <option value="Unmarried">Unmarried</option>
                                            <option value="Married">Married</option>                                           
                                        </select>
                                    </div>
                                    <div class="form-group">
                                    <label>Patient Gender</label>
                                        <select name="patient_gender"  class="form-control form-select" required>
                                        <?php if ($patient_gender !==''){echo '<option value="'._e($patient_gender).'" selected>'.$patient_gender.'</option>'; }?>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                        </select>
                                    </div>
                                    <div  class="form-group">
                                    <label>Patient Blood Group</label>
                                        <select name="blood_group" class="form-control form-select">
                                        <?php if ($blood_group !==''){echo '<option value="'._e($blood_group).'" selected>'.$blood_group.'</option>'; }?>
                                            <option value="">Blood Group</option>
                                            <option value="A+">A+</option>
                                            <option value="A-">A-</option>
                                            <option value="B+">B+</option>
                                            <option value="B-">B-</option>
                                            <option value="O+">O+</option>
                                            <option value="O-">O-</option>
                                            <option value="AB+">AB+</option>
                                            <option value="AB-">AB-</option>
                                        </select>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-lg-12">
                                        <label>Patient Weight</label>
                                            <input name="patient_weight" type="text" class="form-control" value="<?php _e($patient_weight)?>" placeholder="Patient Weight">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-lg-12">
                                        <label>Patient Height</label>
                                            <input name="patient_height" value="<?php _e($patient_height)?>" type="text" class="form-control" placeholder="Patient Height">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-xl-6">
                                    <div class="form-group">
                                    <label>Patient Address</label>
                                        <textarea class="form-control" value="<?php _e($patient_address)?>" name="patient_address" placeholder="Address" rows="4" ></textarea>
                                    </div>
                                </div>
                                <div class="col-xl-6">
                                    <div class="form-group">
                                    <label>Patient History</label>
                                        <textarea class="form-control" value="<?php _e($patient_history)?>" name="patient_history" placeholder="Patient History" rows="4"></textarea>
                                    </div>
                                    <div class="form-group text-right">
                                        <button type="submit" name="patientadd" class="btn btn-primary float-end">Save</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
   </div>
   <?php    

}