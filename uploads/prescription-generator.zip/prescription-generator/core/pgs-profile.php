<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
function pgs_assistant_profile(){}

function  pgs_doctor_profile_page(){ 
    global $wpdb; 


 // Process update form submission

        // Retrieve the current user's email
        $current_user = wp_get_current_user();
        $current_user_email =  esc_attr($current_user->user_email); // Replace this with your actual method to get user email
        $user_id = get_current_user_id();
        $doctor_name= $current_user->display_name;
        // Check if the current user's email exists in the wp_doctor table
        $user_exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM wp_as_doctor WHERE doctor_email = %s", $current_user_email));
        $appoint_status = isset($_POST['appoint_status']) ? "on" : "off";
        
        if (isset($_POST['update_data'])) {
            // Prepare the updated data
            $updated_data = array(
                'doctor_id' => $user_id,
                'doctor_name' => $doctor_name,
                'doctor_degree' => sanitize_text_field($_POST['doctor_degree']),
                'doctor_address' => sanitize_text_field($_POST['doctor_address']),
                'doctor_specialist' => sanitize_text_field($_POST['doctor_specialist']),
                'doctor_appoint_details' => sanitize_text_field($_POST['doctor_appoint_details']),
                'doctor_profile_image_url' => sanitize_text_field($_POST['profile_image_url']),
                'assistant_id' => sanitize_text_field($_POST['assistant_id']),
                'appoint_status' => sanitize_text_field($appoint_status),
                'prescription_form_details' => json_encode(array(
                    
                    'image_url' => sanitize_text_field($_POST['image_url']),
                    'footer_text' => sanitize_text_field($_POST['footer_text']),
                    
                ))
            );
        
            if ($user_exists) {
                // Update the row in the wp_doctor table
                $where = array('doctor_email' => $current_user_email);
                $wpdb->update('wp_as_doctor', $updated_data, $where);

                echo '<div class="alert alert-success alert-dismissible fade show" role="alert">Information Submited Successfully!
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>';
            } else {
                // Insert a new row into the wp_doctor table
                $insert_data = array(
                    'doctor_email' => $current_user_email,
                    'prescription_form_details' => $updated_data['prescription_form_details']
                );
           $wpdb->insert('wp_as_doctor', $insert_data);
                echo '<div class="alert alert-primary alert-dismissible fade show" role="alert">Information Inserted Successfully!
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>';
             
               // print_r($insert_data);
            }
        }



// Retrieve the current user's data
$current_user = wp_get_current_user();
$current_user_email =  esc_attr($current_user->user_email);

$result = $wpdb->get_row($wpdb->prepare("SELECT * FROM wp_as_doctor WHERE doctor_email = %s",$current_user_email));
if($result === null)
{   $demodata= '{
   
    "image_url":"",
    
    "footer_text":"Insert footer text"}';
    
    $prescription_form_details = json_decode($demodata, true);


}else{

$prescription_form_details = json_decode($result->prescription_form_details, true);
}
//print_r($result);

    ?>
        <div class="row" >
            <div class="sidebar col-lg-3 col-sm-12" >
                <?php pgs_side_bar_function();?>
            </div> 
            <div class="col-lg-9 col-sm-12">
                <div class="card">
                    <form id="image-upload-form" method="post" action="">
                    
                        <div class="card-header">
                            <h4 class="card-title">Prescription Header Information </h4>
                        </div>
                        <div class="card-body">                               
                            <div class="form-group">
                                <input type="hidden" name="image_url" id="image_url" value="<?php echo esc_attr($prescription_form_details['image_url']); ?>"class="form-control phone"  placeholder="Insert Image URL" >  
                            </div>
                            <div class="form-group">
                            <label>Header image size : 800px x 200px or 210mm x 50mm</label>
                                <div id="image-preview">
                                    <?php if ($prescription_form_details['image_url'] !== ''): ?>
                                    <img style=" min-width 300px; height:auto;"src="<?php echo esc_url($prescription_form_details['image_url']); ?>" alt="Selected Image">
                                    <?php else: ?>
                                    <p>No image selected.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="hidden" value="<?php echo sanitize_text_field( $current_user_email); ?>" />
                                <input id="imgupload-button" type="button" class="btn btn-info" value="Upload Image" />
                            </div>
                        </div>
                        <div class="card-header">
                            <h4 class="card-title">Prescription Footer Information </h4>
                        </div>
                        <div class="card-body"> 
                            <div class="form-group">
                                <input type="text" value="<?php echo esc_attr($prescription_form_details['footer_text']); ?>" class="form-control phone" name="footer_text" placeholder="Insert footer text" >
                            </div>
                        </div> 
                        <div class="card-header">
                            <h4 class="card-title">Doctor Profile Information </h4>
                        </div>
                        <div class="card-body">                               
                            <div id="prescription-form-submenu-content"class="basic-form">                      
                                <div class="row">
                                    <div class="col-xl-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Doctor Degree</label>
                                            <input type="text" value="<?php isset($result->doctor_degree) ? _e($result->doctor_degree) : '';  ?>" class="form-control patient_name" name="doctor_degree" placeholder="Doctor Degree" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Spesalist</label>
                                            <input type="text"value="<?php isset($result->doctor_specialist) ? _e($result->doctor_specialist) : ''; ?>" class="form-control phone" name="doctor_specialist" placeholder="Specialist" >
                                        </div>
                                        <div class="form-group">
                                            <label>Practice Address</label>
                                            <input type="text" value="<?php isset($result->doctor_address) ? _e($result->doctor_address) : '';  ?>" class="form-control patient_name" name="doctor_address" placeholder="Practice Address" >
                                        </div>
                                        <div class="form-group">
                                            <label>Practice Schedule</label>
                                            <input type="text" value="<?php isset($result->doctor_appoint_details) ? _e($result->doctor_appoint_details) : '';  ?>" class="form-control patient_name" name="doctor_appoint_details" placeholder="Practice Schedule" >
                                        </div>
                                        <div class="form-check form-switch">
                                            <input name="appoint_status" value="on" class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckChecked" <?php isset($result->appoint_status) &&  $result->appoint_status === 'on' ? _e('checked') : ''; ?>>
                                            <label class="form-check-label" for="flexSwitchCheckChecked"> Appointment Enable/Disable</label>
                                            
                                        </div>
                                        
                                    </div>    
                                    <div class="col-xl-6 col-sm-12">

                                        <p>Doctor Profile Image</p>
                                        <div class="form-group">
                                            <div id="image-preview">
                                                <?php if (isset($result->doctor_profile_image_url) && $result->doctor_profile_image_url !== '' ): ?>
                                                <img style=" width:80px; height:80px;"src="<?php echo esc_url($result->doctor_profile_image_url); ?>" alt="Selected Image">
                                                <?php else: ?>
                                                <p>No image selected.</p>
                                                <?php endif; ?>
                                            </div>
                                            <label>Upload Image Size 300px x 300px </label> 
                                            <input type="hidden" name="profile_image_url" id="profile_image_url"  value="<?php isset($result->doctor_profile_image_url) && $result->doctor_profile_image_url !== '' ? _e($result->doctor_profile_image_url) : ''; ?>"class="form-control phone"  placeholder="Insert Image URL" >
                                            <input id="profile_image_button" type="button" class="btn btn-info" value="Upload Image" />
                                        </div>
                                        <div class="form-group">
                                        <label>Select your assistent</label>   
                                            <?php
                                            // Retrieve users with the role 'assistant'
                                            $users = get_users(array('role' => 'assistant'));

                                            // Get user data based on user ID
                                            $assistant_data = get_userdata(esc_attr($result->assistant_id));

                                            // Output the HTML for the multi-select input field
                                            echo '<select name="assistant_id">';
                                            echo '<option>Select an assistent</option>';
                                            if ($assistant_data !== '') {
                                                $assistant_name = $assistant_data->display_name; // User name
                                             
                                                echo '<option value="' . esc_attr($result->assistant_id) . '"selected>' . esc_attr($assistant_name) . '</option>';
                                           
                                            } 
                                            foreach ($users as $user) {
                                                echo '<option value="' . esc_attr($user->ID) . '">' . esc_html($user->display_name) . '</option>';
                                            }
                                            echo '</select>';
                                            ?>
                                        </div>
                                    </div>
                                </div>                                    
                            </div>
                        </div>
                        <div class="card-footer text-right">
                            <div class="form-group mt-3"> 
                                <input type="submit" class="btn btn-success" name="update_data" value="Submit">
                            </div> 
                        </div>
                    </form>
                </div>
            </div> 
        </div>
    
    <?php



} ?>


