<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
function pgs_prescription_form_setting() {

if (isset($_POST['dosage_description'])) {
   echo $_POST['dosage_description'];
}elseif(isset($_POST['dosage_time'])){ echo $_POST['dosage_time'];}
elseif(isset($_POST['dosage_long'])){ echo $_POST['dosage_long'];}
else{}
    ?>
<div class="row">
    <div class="col-6">Dosage Description: 
        <form action="" method="post"> <input type="text" name="dosage_description" id=""><button type="submit"Value="Submit">Submit</button></form>
    </div>
    <div class="col-6">
        <ul>
            <li>1</li>
            <li>2</li>
            <li>3</li>
            <li>4</li>
        </ul>
    </div>
</div>
<div class="row">
    <div class="col-6">Dosage Time: 
        <form action="" method="post"> <input type="text" name="dosage_time" id=""><button type="submit" Value="Submit">Submit</button></form>
    </div>
    <div class="col-6">
        <ul>
            <li>1</li>
            <li>2</li>
            <li>3</li>
            <li>4</li>
        </ul>
    </div>
</div>
<div class="row">
    <div class="col-6">Day Long:
        <form action="" method="post"> <input type="text" name="dosage_long" id=""><button type="submit"Value="Submit">Submit</button></form>
    </div>
    <div class="col-6">
        <ul>
            <li>1</li>
            <li>2</li>
            <li>3</li>
            <li>4</li>
        </ul>
    </div>
</div>
Fotter Details
<form action="" method="post"> <input type="text" name="" id=""><button type="submit" Value="Submit">Submit</button></form>
<?php
}

function pgs_dosage_add(){}
function pgs_dosage_edit(){}
function pgs_dosage_delate(){}
?>