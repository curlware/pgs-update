<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// Shortcode for Doctor Dashboard
function pgs_dashboard_shortcode() {
    ob_start();
  // Check if the user is logged in and has the manager role
if (is_user_logged_in() && current_user_can('doctor') || current_user_can('administrator')) {
    $user_id = get_current_user_id();
   
    pgs_doctor_dashboard_function();
} elseif (is_user_logged_in() && current_user_can('assistant')) {
    $user_id = get_current_user_id();
    pgs_assistant_dashboard_function();
    // Display links based on user role
   
}

else {
    // If the user is not a manager, display an error message
    echo '<p class="error-message">You do not have permission to access this page. Go to <a href="'.site_url('pgs-login').'">Login</a></p>';
}
    return ob_get_clean();
}
add_shortcode('pgs_dashboard', 'pgs_dashboard_shortcode');
// Shortcode for Doctor Dashboard
function pgs_new_prescription_shortcode() {
    ob_start();
  // Check if the user is logged in and has the manager role
if (is_user_logged_in() && current_user_can('doctor') || current_user_can('administrator')) {
    $user_id = get_current_user_id();
    include ( plugin_dir_path( __FILE__ ).'view/new-prescription.php' );
   
} elseif (is_user_logged_in() && current_user_can('assistant')) {
    echo '<p class="error-message">You do not have permission to access this page. Go to <a href="'.site_url('pgs-login').'">Login</a></p>';
   
}

else {
    // If the user is not a manager, display an error message
    echo '<p class="error-message">You do not have permission to access this page. Go to <a href="'.site_url('pgs-login').'">Login</a></p>';
}
    return ob_get_clean();
}
add_shortcode('pgs_new_prescription', 'pgs_new_prescription_shortcode');





//prescription print short code

add_shortcode('pgs_prescription_print', 'pgs_print_shortcode');



// Include WordPress core functions
include_once(ABSPATH . 'wp-includes/pluggable.php');

// Define the custom login shortcode
function patient_list_shortcode() {
    ob_start();

    if (is_user_logged_in() && current_user_can('doctor') || current_user_can('administrator')) {
        $user_id = get_current_user_id();
      
    
        patient_list_page();
       
    } elseif (is_user_logged_in() && current_user_can('assistant')) {
        $user_id = get_current_user_id();
        patient_list_page();
        // Display links based on user role
       
    }
    
    else {
        // If the user is not a manager, display an error message
        echo '<p class="error-message">You do not have permission to access this page.  Go to <a href="'.site_url('pgs-login').'">Login</a></p>';
    }

    return ob_get_clean();
}

// Register the shortcode
add_shortcode('pgs_patient_list', 'patient_list_shortcode');

// Define the custom login shortcode
function patient_add_shortcode() {
    ob_start();

    if (is_user_logged_in() && current_user_can('doctor') || current_user_can('administrator')) {
        $user_id = get_current_user_id();
      
    
    patient_add_page();
       
    } elseif (is_user_logged_in() && current_user_can('assistant')) {
        $user_id = get_current_user_id();
        patient_add_page();
       
    }
    
    else {
        // If the user is not a manager, display an error message
        echo '<p class="error-message">You do not have permission to access this page.  Go to <a href="'.site_url('pgs-login').'">Login</a></p>';
    }

    return ob_get_clean();
}

// Register the shortcode
add_shortcode('pgs_patient_add', 'patient_add_shortcode');

// Define the custom login shortcode
function prescription_list_shortcode() {
    ob_start();

    if (is_user_logged_in() && current_user_can('doctor') || current_user_can('administrator')) {
        $user_id = get_current_user_id();
        prescription_list_page();
       
    } elseif (is_user_logged_in() && current_user_can('assistant')) {
        $user_id = get_current_user_id();
        prescription_list_page();
        // Display links based on user role
       
    }
    
    else {
        // If the user is not a manager, display an error message
        echo '<p class="error-message">You do not have permission to access this page.  Go to <a href="'.site_url('pgs-login').'">Login</a></p>';
    }

    return ob_get_clean();
}

// Register the shortcode
add_shortcode('pgs_prescription_list', 'prescription_list_shortcode');

// Define the custom login shortcode
function pgs_profile_shortcode() {
    ob_start();

    if (is_user_logged_in() && current_user_can('doctor') || current_user_can('administrator')) {
        $user_id = get_current_user_id();
     pgs_doctor_profile_page();
       
    } elseif (is_user_logged_in() && current_user_can('assistant')) {
        $user_id = get_current_user_id();
        pgs_assistant_profile();
       
    }
    
    else {
        // If the user is not a manager, display an error message
        echo '<p class="error-message">You do not have permission to access this page.  Go to <a href="'.site_url('pgs-login').'">Login</a></p>';
    }

    return ob_get_clean();
}

// Register the shortcode
add_shortcode('pgs_profile', 'pgs_profile_shortcode');

// Register the login function
add_action('init','pgs_login_function');
function pgs_login_function() {
  global $pgs_error;
  $pgs_error = false;
  if (isset($_POST['username']) && isset($_POST['password'])) {
    $creds = array();
    $creds['user_login'] = $_POST['username'];
    $creds['user_password'] = $_POST['password'];
    //$creds['remember'] = false;
    $user = wp_signon( $creds );
    if ( is_wp_error($user) ) {
      $pgs_error = $user->get_error_message();
    } else {
      // if (isset($_POST['redirect']) && $_POST['redirect']) {
      //   wp_redirect($_POST['redirect']);
      // }
       // Successful login, redirect to dashboard
       wp_redirect(site_url('/pgs-dashboard'));
       exit(); // Make sure to exit after redirect
    }
  }
}

// shows error message
function the_pgs_error() {
  echo get_pgs_error();
}

function get_pgs_error() {
  global $pgs_error;
  if ($pgs_error) {
    $return = $pgs_error;
    $pgs_error = false;
    return $return;
  } else {
    return false;
  }
}

// shows login form (or a message, if user already logged in)
function get_pgs_login_form($redirect=false) {
  if (!is_user_logged_in()) {
    $return = "<div class=\"row  d-flex justify-content-center\">
    <div class=\"col-md-6 col-lg-4\"><form action=\"\" method=\"post\" class=\"pgs_form card pgs_login p-4 m-4\">
    <h5 class=\"card-title text-center fw-400\">Sign Up</h5>\r\n";
    $error = get_pgs_error();
    if ($error)
      $return .= "<p class=\"alert alert-danger alert-dismissible fade show\" role=\"alert\">{$error} <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">
      <span aria-hidden=\"true\">&times;</span>
    </button></p>\r\n";
    $return .= "  <div class=\"form-group\">
      <label for=\"pgs_username\">".__('Username','asprescription')."</label>
      <input class=\"form-control\" type=\"text\" id=\"pgs_username\" name=\"username\" value=\"".(isset($_POST['username'])?$_POST['username']:"")."\"/>
      </div>\r\n";
    $return .= "<div class=\"form-group\">
      <label for=\"pgs_password\">".__('Password','asprescription')."</label>
      <input class=\"form-control\" type=\"password\" id=\"pgs_password\" name=\"password\"/>
      </div>\r\n";
    if ($redirect)
      $return .= " <div class=\"form-group\"> <input type=\"hidden\" name=\"redirect\" value=\"{$redirect}\">\r\n";
    $return .= "  <button class=\"btn btn-primary\"  type=\"submit\">".__('Login','asprescription')."</button>\r\n";
    $return .= " </div></form></div>
    </div>\r\n";
  } else {
    $return = "<p>".__('User is already logged in. Go to <a href="'.site_url().'/pgs-dashboard">Dashboard</a>','asprescription')."</p>";
  }
  return $return;
}

function the_pgs_login_form($redirect=false) {
  echo get_pgs_login_form($redirect);
}

// adds a handy [pgs_login] shortcode to use in posts/pages
add_shortcode('pgs_login','pgs_login_shortcode');
function pgs_login_shortcode ($atts,$content=false) {
  $atts = shortcode_atts(array(
    'redirect' => false
  ), $atts);
  return get_pgs_login_form($atts['redirect']);
}

// prescription Appointment shortcode start

add_shortcode('pgs_appointment_form', 'appointment_form_shortcode');

add_shortcode('pgs_appointment_list', 'doctor_appointment_dashboard_shortcode');

add_shortcode('pgs_appointment_setting', 'doctor_appointment_setting_shortcode');











?>