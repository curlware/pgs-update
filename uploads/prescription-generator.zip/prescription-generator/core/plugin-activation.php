<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
function pgs_prescription_form_activation(){
    add_role('doctor', 'Doctor', []);
    add_role('assistant', 'Assistant', []);
    
    include ( plugin_dir_path( __FILE__ ).'create-db.php' );
    pgs_create_tables();
    pgs_system_activate_page_create();
}
// Add capabilities to existing roles if necessary
function add_gallary_use_capabilities() {
    $roles = array('doctor', 'assistant');

    foreach ($roles as $role) {
        $existing_role = get_role($role);
        if ($existing_role) {
            $existing_role->add_cap('upload_files');
        }
    }
}
add_action('init', 'add_gallary_use_capabilities');

function pgs_system_activate_page_create() {
    // Array of pages to create
    $pages = array(
        'pgs_dashboard' => array(
            'path' => 'pgs-dashboard', 
            'title' => 'PGS Dashboard',
            'shortcode' => '[pgs_dashboard]',
        ),
        'pgs_new_prescription' => array(
            'path' => 'new-prescription', 
            'title' => 'New Prescription',
            'shortcode' => '[pgs_new_prescription]',
        ),
        'pgs_prescription_list' => array(
            'path' => 'prescription-list', 
            'title' => 'Prescription List',
            'shortcode' => '[pgs_prescription_list]',
        ),
        'pgs_prescription_print' => array(
            'path' => 'prescription-print', 
            'title' => 'Prescription Print',
            'shortcode' => '[pgs_prescription_print]',
        ),
        'pgs_patient_list' => array(
            'path' => 'patient-list', 
            'title' => 'Patient List',
            'shortcode' => '[pgs_patient_list]',
        ),
        'pgs_patient_add' => array(
            'path' => 'patient-add', 
            'title' => 'Patient Add',
            'shortcode' => '[pgs_patient_add]',
        ),
        'pgs_profile' => array(
            'path' => 'pgs-profile', 
            'title' => 'PGS Profile',
            'shortcode' => '[pgs_profile]',
        ),
        'pgs_login' => array(
            'path' => 'pgs-login', 
            'title' => 'PGS Login',
            'shortcode' => '[pgs_login]',
        ),
        'pgs_appointment_form' => array(
            'path' => 'appointment-form', 
            'title' => 'Appointment Form',
            'shortcode' => '[pgs_appointment_form]',
        ),
        'pgs_appointment_list' => array(
            'path' => 'appointment-list', 
            'title' => 'Appointment List',
            'shortcode' => '[pgs_appointment_list]',
        ),
        'pgs_appointment_setting' => array(
            'path' => 'appointment-setting', 
            'title' => 'Appointment Setting',
            'shortcode' => '[pgs_appointment_setting]',
        ),
    );

    foreach ($pages as $page_key => $page_data) {
        $page_path = $page_data['path'];
        $page_title = $page_data['title'];
        $page_content = $page_data['shortcode'];
        // Check if the page exists by path
    $page_check = get_page_by_path($page_path);

        if (!$page_check) {
            $page = array(
                'post_type' => 'page',
                'post_title' => $page_title,
                'post_content' => $page_content,
                'post_status' => 'publish',
                'post_author' => 1,
            );

            wp_insert_post($page);
        }
    }    
}