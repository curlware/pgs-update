<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
function prescription_list_page(){
    ?>

<div class="row" >
    <div class="sidebar col-lg-3 col-sm-12" >
    <?php pgs_side_bar_function();?>
    </div>
    <div class="col-lg-9 col-sm-12  overflow-auto ">
        <table id="prescriptionList" class="display table table-striped table-bordered" >
            <thead>
                <tr>
                    <th>Patient Name</th>
                    <th>Patient Id</th>
                    <th>Mobile</th>
                    <th>Date</th>
                    <th>Doctor Name</th>
                    <th>Details</th>
                </tr>
            </thead>
            <?php 
                    global $wpdb;
                    $prescription_data = $wpdb->get_results("SELECT patient_name, patient_id, doctor_name, patient_mobile, id, date FROM wp_as_pescription");
                    foreach ($prescription_data as $data) {
                        $printurl= 'prescription-print/?page=prescription-print&printid='.$data->id;

                        echo "<tr><td>{$data->patient_name}</td><td>{$data->patient_id}</td><td>{$data->patient_mobile}</td><td>{$data->date}</td><td>{$data->doctor_name}</td><td><a href='".site_url($printurl)."'>print</a></td></tr>";
                    }
                    ?>
            <tfoot>
                <tr>
                    <th>Patient Name</th>
                    <th>Patient Id</th>
                    <th>Mobile</th>
                    <th>Date</th>
                    <th>Doctor Name</th>
                    <th>Details</th>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
<script>new DataTable('#prescriptionList', {
 
 buttons: [
     'copy', 'excel', 'pdf'
 ],

});</script>



<?php
} 