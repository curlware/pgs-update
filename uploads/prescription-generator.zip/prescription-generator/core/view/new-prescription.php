<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
 // Search functionality
 if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['psearch']) && $_GET['psearch'] !=='') {
    $search_term = sanitize_text_field($_GET['psearch']);
    global $wpdb;

    $search_results = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM wp_as_patient WHERE id = %d OR patient_mobile = %d", $search_term, $search_term
          
        )
    );
}
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['patientid']) && $_GET['patientid'] !=='') {
    $patient_id = sanitize_text_field($_GET['patientid']);
    $current_user = wp_get_current_user();
    $doctor_email= $current_user->user_email;
    global $wpdb;
    $patient_details = $wpdb->get_row("SELECT * FROM wp_as_patient WHERE id = '$patient_id'");
    $pescription_results = $wpdb->get_results("SELECT * FROM wp_as_pescription WHERE patient_id = $patient_id AND doctor_email = '$doctor_email'");
       
}

if (isset($patient_details) && !empty($patient_details)) {
    $patient_name=$patient_details->patient_name;
    $blood_group=$patient_details->blood_group;
    $patient_gender=$patient_details->patient_gender;
    $patient_address=$patient_details->patient_address;
    $patient_mobile=$patient_details->patient_mobile;
    $patient_age=$patient_details->patient_age;
    $patient_weight=$patient_details->patient_weight;
    $patient_height=$patient_details->patient_height;
}else{ $patient_name='';
    $blood_group='';
    $patient_gender='';
    $patient_address='';
    $patient_mobile='';
    $patient_age='';
    $patient_id='';
    $patient_weight='';
    $patient_height='';
}

?>
    <div class="wrap">
        <div class="presMain section  g-6 ">

            <div class="row pb-10 g-6 " >
                <div class="col-lg-6 col-sm-12 "><!-- Search Bar -->
                    <form method="get" >
                        <input type="hidden" name="page" value="prescription-form"> 
                        <label >Search by Patient ID or Phone:</label> 
                        <div style="padding-left:10px;padding-right:10px;" class= " input-group">
                            <input class=" form-control" type="text" name="psearch" placeholder="Enter Patient ID or Phone">
                            <div class="input-group-append"> <input  class=" btn btn-primary" type="submit" value="Search"> </div>
                        </div>
                    </form>
                   
                     </div>     <div class="col-lg-6 col-sm-12 ">     
                     <?php
                            // Display search results
                            if (isset($search_results) && !empty($search_results)) {?>
                        <!-- Display the DataTable -->
                    <table id="patient-datatable" class="display table col-12">
                        <thead>
                            <tr>
                                <th>Patient Name</th>
                                <th>Patient ID</th>
                            
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                                foreach ($search_results as $result) {
                                    echo "<tr class='patientid' data-href='".site_url('/new-prescription/?patientid='.$result->id)."'><td>{$result->patient_name}</td><td >{$result->id} <input type='button' class='btn btn-primary float-right rounded' value='Add'></td></tr>";
                                }?>
                          
                        </tbody>
                    </table>
                    <!-- Display the DataTable -->
                     <?php   } 
                            ?>
                               <?php
                                // Display search results
                                if (isset($pescription_results) && !empty($pescription_results)) {
                                    ?> <h5>Pescription List</h5>
                                    <style>.accordientlist{padding:10px 5px 10px 20px;background:#f1eeee;border-bottom:0.5px solid #373737;}</style>
                                    <div id="accordion" style="max-height: 160px;list-style: none;overflow: scroll; ">  <?php

                                    foreach ($pescription_results as $result) {
                                        echo   '
                                        
                                        <li class="accordientlist" data-toggle="collapse" data-target="#collapse'.$result->id.'" aria-expanded="true" aria-controls="collapse'.$result->id.'">
                                        <span class="dashicons dashicons-insert"></span> <span >  '.$result->date.' </span>
                                        </li>
                                        <div id="collapse'.$result->id.'" class="collapse" aria-labelledby="heading'.$result->id.'" data-parent="#accordion">
                                    '.$result->medicine.'
                                        </div>  
                                        
                                        ';
                                    }
                                    ?>
</div>
                                    <?php  
                                } 
                                ?>
                     
                        
                    
                </div>
            </div>
                
                <div class="row  " style="padding-top:50px;">
                    <div class="col-lg-12 col-sm-12">
                        <form class="presform" method="post">
                        
                            <div class="form-group row">
                               
                                <div class="col-sm-3">
                                <label >Patient Name:</label>
                                    <input type="text" class="form-control patient_name" value="<?php _e($patient_name)?>" name="patient_name" placeholder="Patient Name"
                                        required>
                                </div>
                            
                                <div class="col-sm-1">
                                <label >Age:</label>
                                    <input type="text" class=" form-control age"  value="<?php _e($patient_age)?>" name="patient_age" placeholder="Age" required>
                                </div>
                                <div class="col-sm-2">
                                <label >Patient Gender:</label>
                                <select name="patient_gender"  value="<?php _e($patient_gender)?>"  class=" form-control age" >
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                    </select>
                                </div>
                                <div class="col-sm-2">
                                <label >Patient Weight:</label>
                                    <input type="text" value="<?php _e($patient_weight)?>"  class=" form-control age" name="patient_weight" placeholder="Weight" >
                                </div>
                                <div class="col-sm-2">
                                <label >Patient Mobile:</label>
                                    <input type="text"  value="<?php _e($patient_mobile)?>" class=" form-control age" name="patient_mobile" placeholder="Phone" >
                                </div>
                                <div class="col-sm-2">
                                <label >Address:</label>
                                    <input type="text"  value="<?php _e($patient_address)?>" class="form-control patient_name" name="patient_address" placeholder="Patient Address" >
                                </div>
                            </div>
                    
                            <div class="form-group row">
                            <div class="col-sm-2">
                            <label >Patient Height:</label>
                                <input type="text"  value="<?php _e($patient_height)?>" class="form-control" name="patient_height" placeholder="Patient Height" >
                            </div>
                            <div class="col-sm-2 ">
                                <label >Blood Group:</label>
                                    <select name="blood_group"   class="form-control form-select">
                                    <?php if ($blood_group !==''){echo '<option value="'._e($blood_group).'" selected>'.$blood_group.'</option>'; }?>
                                        <option value="">Blood Group</option>
                                        <option value="A+">A+</option>
                                        <option value="A-">A-</option>
                                        <option value="B+">B+</option>
                                        <option value="B-">B-</option>
                                        <option value="O+">O+</option>
                                        <option value="O-">O-</option>
                                        <option value="AB+">AB+</option>
                                        <option value="AB-">AB-</option>
                                    </select>
                                </div>      
                           
                            <div class="col-sm-4">
                            <label >C/C:</label>
                                <input type="text" class="form-control" name="clinicalcase" placeholder="C/C" >
                            </div>
                            
                            <div class="col-sm-2">
                            <label >C/C:</label>
                                <button type="button"  onclick="openForm()" class="btn btn-primary" data-toggle="modal" data-target="#popupForm">Add O/E</button>
                            </div>
                            <div class="col-sm-2"> 
                            <label >Patient ID:</label>
                                <input type="text" class=" form-control age" id="patient_id" value="<?php _e($patient_id)?>"  name="patient_id" placeholder="Patient Id" value="" readonly></div>
                            
                            </div>


                                <!-- Popup Form -->
                            <div class="modal" id="popupForm" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" style="z-index:999999;" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Popup Form</h5>
                                    <button type="button"  onclick="closeForm()" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <!-- Form with 6 input fields -->
                                    
                                    <div class="form-group">
                                        <label for="bp">BP</label>
                                        <input type="text" class="form-control" id="bp" placeholder="120/80">
                                    </div>
                                    <div class="form-group">
                                        <label for="pulse">Pulse</label>
                                        <input type="text" class="form-control" id="pulse" placeholder="72">
                                    </div>
                                    <div class="form-group">
                                        <label for="spo2">SpO2</label>
                                        <input type="text" class="form-control" id="spo2" placeholder="Enter SpO2 rate">
                                    </div>
                                    <div class="form-group">
                                        <label for="anaemia">Anaemia</label>
                                        <input type="text" class="form-control" id="anaemia">
                                    </div>
                                    <div class="form-group">
                                        <label for="jaubdice">Jaundice</label>
                                        <input type="text" class="form-control" id="jaubdice" >
                                    </div>
                                    <div class="form-group">
                                        <label for="etc">Othres</label>
                                        <input type="textarea" class="form-control" id="etc" placeholder="Enter Other Description">
                                    </div>

                                    
                                    
                                </div>
                                <div class="modal-footer">
                                    <button type="button " class="btn btn-primary" data-dismiss="modal"  onclick="closeForm()" >Add</button>
                                </div>
                                </div>
                                </div>
                            </div>
                            <div id="pharmaceuticalForm">
                                        <div class="repeatable-field">
                                            <div class="form-group row">
                                                <label class="col-sm-2 col-form-label">Medication:</label>
                                                <div class="col-sm-5">
                                                    <input type="text" class=" form-control searchSelect" list="optionsList"
                                                        placeholder="Search or select an option" name="medication_name[]" required>
                                                </div>
                                                <label class="col-sm-2 col-form-label" >Dosage:</label>
                                                <div class="col-sm-3"><input type="text" class="form-control dosage" list="dosageList" name="dosage[]" required
                                                        placeholder="1 + 0 + 1">
                                                        
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-sm-2 col-form-label" >Dosage Description:</label>
                                                <div class="col-sm-5">
                                                    <input type="text" class="form-control dosagedcrp" list="dosageEat" name="dosagedcrp[]"
                                                        placeholder="Medication Extra Description">

                                                </div>

                                                <label class="col-sm-2 col-form-label" >Day Long:</label>
                                                <div class="col-sm-2"> <input class="form-control" placeholder="3 Days" list="dayList" name="frequency[]">
                                                </div>
                                                <div class="col-sm-1"><button type="button" class=" btn btn-danger removeField">Remove</button></div>
                                            </div>
                                                
                                            
                                        </div>
                                    </div>
                                        <div style="margin-top:5px;">
                                    <button type="button" class="btn btn-success" id="addField">Add Another Medicine</button>
                                    <button type="submit" name="newprescription" class="btn btn-primary" id="submitBtn">Submit</button>
                                        </div>
                        </form>
                    </div>
                </div>

            
            <datalist id="dosageList" >
                <option value="১ + ০ + ১">
                <option value="১ + ১ + ১">
                <option value="০ + ০ + ১">
                <option value="১ + ০ + ০">
                <option value="০ + ১ + ০">
            </datalist>
                <datalist id="dayList" >
                <option value="১ দিন ">
                <option value="৩ দিন ">
                <option value="৭ দিন ">
                <option value="১০ দিন ">
                <option value="১৫ দিন ">
                <option value="৩০ দিন ">
                <option value="২ মাস ">
                <option value="চলবে">
            </datalist>
            <datalist id="dosageEat" >
                <option value="খাবারের পর ">
                <option value="খাবারের আগে ">
                <option value="খাবারের মাঝে ">
                <option value="খাবারের ১৫ মিনিট পরে ">
                <option value=" খাবারের ১৫ মিনিট আগে">
                <option value="খাবারের ৩০ মিনিট পরে ">
                <option value=" খাবারের ৩০ মিনিট আগে">
                <option value="১ ঘন্টা পরে খাবার">
                <option value="১ ঘন্টা আগে খাবার">
            </datalist>
    
        </div>
    
    </div>

  <script>function openForm() {
    document.getElementById("popupForm").style.display = "block";
  }

  function closeForm() {
    document.getElementById("popupForm").style.display = "none";
  }
  
  jQuery(document).ready(function($) {
    //$('#patient_id').val($(this).data('patientid'));
    $('.patientid').click(function () {window.location = $(this).data("href"); });
            // Initialize DataTable
            $('#prescription-data-table').DataTable();
        });
  
//drag list

const options = jsonData.aaData.map(item => item[2] + " " + item[5]);


// Function to update the options in the dropdown
function updateOptions(filteredOptions, datalist) {
    datalist.empty();
    filteredOptions.forEach(option => {
        jQuery('<option>').val(option).appendTo(datalist);
    });
}

jQuery(document).ready(function () {
    const form = jQuery('#pharmaceuticalForm');
    const repeatableFieldContainer = form.find('.repeatable-field').first().clone();
    const datalist = jQuery('<datalist>').attr('id', 'optionsList');
    updateOptions(options, datalist);
    jQuery('body').append(datalist);

   

    form.on('input', '.searchSelect', function () {
        const searchText = jQuery(this).val().toLowerCase();
        const filteredOptions = options.filter(option =>
            option.toLowerCase().includes(searchText)
        );
        updateOptions(filteredOptions, datalist);
    });




    form.on('click', '.removeField', function () {
        jQuery(this).closest('.repeatable-field').remove();
    });

    jQuery('#addField').click(function () {
        const newField = repeatableFieldContainer.clone();
        form.append(newField);
    });

    
});

  </script>
 <?php

