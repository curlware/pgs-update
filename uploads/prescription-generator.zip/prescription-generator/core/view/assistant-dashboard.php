<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
function pgs_assistant_dashboard_function(){
?>
<div class="row" >
        <div class="sidebar col-lg-3 col-sm-12" >
            <?php pgs_side_bar_function();?>
        </div>
        <div class="dash col-lg-9 col-sm-12">
           <?php  
           $user_id = get_current_user_id();
            global $wpdb;
             $doctor_details = $wpdb->get_row("SELECT doctor_id FROM wp_as_doctor WHERE assistant_id = '$user_id'");
             if (isset($doctor_details->doctor_id) && $doctor_details->doctor_id > 0 ) {
               $doctor_id = $doctor_details->doctor_id;
    ?>
     <div class="pgs-dashboard">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title text-center">Assistant Panel</h3>
                </div>
                <div class="row card-body">
                    <div class="col-lg-3 col-sm-6">
                        <div class="card gradient-1" >
                            <div class="card-body">
                                <h4 class="card-title text-white pb-3 fz-16">Total Appointments</h4>
                                <div class="d-inline-block">
                                <?php
                                    global $wpdb;
                                        // Calculate the total appointment count for the current user
                                        $total_appointments_count = $wpdb->get_var("SELECT COUNT(*) FROM wp_as_appointments WHERE doctor_id = '$doctor_id'");

                                        echo "<h2 class=\"text-white fz-16\">$total_appointments_count </h2>";
                                    
                                    ?>
                                    
                                </div>
                                <span class="float-right mr-4 p-2 mb-4 opacity-50"> <span style="font-size:4rem;" class="text-light dashicons dashicons-buddicons-buddypress-logo"></span></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card gradient-2" >
                            <div class="card-body">
                                <h4 class="card-title text-white fz-16">Total Pending Appointments</h4>
                                <div class="d-inline-block">
                                <?php
                                    global $wpdb;

                                        // Calculate the total appointment count for the current user
                                        $total_appointments_count = $wpdb->get_var("SELECT COUNT(*) FROM wp_as_appointments WHERE doctor_id = '$doctor_id' AND appoint_status = 'pending'");

                                        echo "<h2 class=\"text-white fz-16\">$total_appointments_count </h2>";
                                    
                                    ?>
                                    
                                </div>
                                <span class="float-right mr-4 p-2 mb-4 opacity-50"> <span style="font-size:4rem;" class="text-light dashicons dashicons-groups"></span></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card gradient-3" >
                            <div class="card-body">
                                <h4 class="card-title text-white fz-16">Total Created Prescriptions</h4>
                                <div class="d-inline-block">
                                <?php
                                    global $wpdb;

                                        // Calculate the total appointment count for the current user
                                        $total_appointments_count = $wpdb->get_var("SELECT COUNT(*) FROM wp_as_pescription WHERE doctor_id = '$user_id'");

                                        echo "<h2 class=\"text-white fz-16\">$total_appointments_count </h2>";
                                    
                                    ?>
                                    
                                </div>
                                <span class="float-right mr-4 p-2 mb-4 opacity-50"> <span style="font-size:4rem;" class="text-light mr-4 dashicons dashicons-welcome-widgets-menus"></span></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card gradient-4" >
                            <div class="card-body">
                                <h4 class="card-title text-white fz-16">Total Registered Patients </h4>
                                <div class="d-inline-block">
                                <?php
                                    global $wpdb;

                                        // Calculate the total appointment count for the current user
                                        $total_appointments_count = $wpdb->get_var("SELECT COUNT(*) FROM wp_as_patient ");

                                        echo "<h2 class=\"text-white fz-16\">$total_appointments_count </h2>";
                                    
                                    ?>
                                    
                                </div>
                                <span class="float-right mr-4 p-2 mb-4 opacity-50"> <span style="font-size:4rem;" class="text-light mr-4 dashicons dashicons-welcome-widgets-menus"></span></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card mt-3">
                <div class="card-header">
                    <h3 class="card-title">Today Pending Appointments</h3>
                </div>
                <div class="card-body"> 
                    <div class="row overflow-auto">
                        <table id="appointmentList" class="display table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Patient Name</th>
                                    <th>Patient Id</th>
                                    <th>Mobile</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Daily Serial</th>
                                    <th>Doctor Name</th>
                                </tr>
                            </thead>
                            <tbody>
                                    <?php
                                    global $wpdb;

                                    // Calculate today's date in the format used in the database (adjust if necessary)
                                    $today_date = date('Y-m-d');
                                    $appointments_data = $wpdb->get_results("SELECT * FROM wp_as_appointments WHERE doctor_id = '$doctor_id' AND appointment_date = '$today_date' AND appoint_status = 'Pending'");
                                    
                                        foreach ($appointments_data as $data) {
                                            $new_prescription_url = 'new-prescription/?patientid=' . $data->patient_id;

                                            echo "<tr><td>{$data->patient_name}</td><td>{$data->patient_id}</td><td>{$data->patient_mobile}</td><td>{$data->appointment_date}</td><td>{$data->appointment_time}</td><td>{$data->appointment_daily_id}</td><td>{$data->doctor_name}</td></tr>";
                                        }
                                    
                                    ?>
                            </tbody>       
                            <tfoot>
                                <tr>
                                    <th>Patient Name</th>
                                    <th>Patient Id</th>
                                    <th>Mobile</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Daily Serial</th>
                                    <th>Doctor Name</th>
                                </tr>
                            </tfoot>    
                        </table>
                    </div>   
                </div>
            </div>
        </div>
    <?php

             }else{  echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">You are not permited.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>';}
                            ?> 
        
        
        </div>
    </div>
    <script>
        new DataTable('#appointmentList', {
        
        buttons: [
            'copy', 'excel', 'pdf'
        ],

        });
        </script>  
    <?php } ?>