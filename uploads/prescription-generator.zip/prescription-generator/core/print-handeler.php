<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// prescription page size full size a4( 210mm x 297mm )
// header = 60mm
// menu = 25-30mm
//body = 190mm
//footer 

function pgs_print_shortcode(){if(isset($_GET['psid'])){
    $pid =  $_GET['psid'] ;
  
  }else{$pid ='';}
  
  if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['psearch']) && $_GET['psearch'] !== '') {
      $search_term = sanitize_text_field($_GET['psearch']);
      global $wpdb;
  
      $search_results = $wpdb->get_results(
          $wpdb->prepare(
              "SELECT id, patient_name, patient_id, patient_mobile, date, medicine FROM wp_as_pescription WHERE patient_id =  %d OR patient_mobile = %d", $search_term, $search_term
            
          )
      );
      ?> <!-- Display the DataTable -->
      <table id="patient-datatable" class="display table">
          <thead>
              <tr>
                  <th>Patient Name</th>
                  <th>Patient ID</th>
                  <th>Date</th>
                  <th>Print</th>
              </tr>
          </thead>
          <tbody>
              <?php
              // Display search results
              if (isset($search_results) && !empty($search_results)) {
                  foreach ($search_results as $result) {
                      echo "<tr><td>{$result->patient_name}</td><td>{$result->patient_id}</td><td>{$result->date}</td><td> <a href='?page=prescription-print&printid={$result->id}'>print</a></td></tr>";
                  }
              } 
              ?>
          </tbody>
      </table> 
         <?php
  }elseif($_SERVER['REQUEST_METHOD'] === 'GET' &&  isset($_GET['printid']))
  {
      $pid = sanitize_text_field($_GET['printid']);
    echo  pgs_search_prescription_print($pid);
   
      
  }
  
  
  else{
  
     // Search functionality
   
  
  ?> <div class="row  d-flex justify-content-center">
        <form method="get" class="md-float-material form-material col-md-8 col-lg-8">
            <div class="auth-box card p-4 m-4">                
                    <input type="hidden" name="page" value="prescription-print">
                    <div class="form-group">
                        <label for="psearch">Search by Patient ID or Phone:</label>
                        <input type="text" name="psearch" class="form-control" placeholder="Enter Patient ID or Phone">
                    </div>
                    <div class="form-group">
                        <input type="submit" value="Search" class="btn btn-primary" >
                    </div>           
                </div>
        </form>
    </div>
  <?php
  
  }
  }





function pgs_search_prescription_print($pid){
    if (is_user_logged_in() && current_user_can('doctor') || current_user_can('administrator')) {
        $user_id = get_current_user_id();
      
    $newprescription='<a href="'.site_url('new-prescription').' "><button  class="btn btn-success ml-5">New Prescription</button></a>';
    }else{$newprescription='';}

    global $wpdb;
    $dgdata = $wpdb->get_row("SELECT patient_name, patient_id, doctor_name, doctor_email, medicine, clinicalreport, date FROM wp_as_pescription WHERE id = $pid");
   if($dgdata){
    $doctor_email=$dgdata->doctor_email;
    $pids= $dgdata->patient_id;
    $pdata =$wpdb->get_row("SELECT patient_name, patient_age, blood_group, patient_mobile, patient_gender, patient_address, patient_weight, patient_height FROM wp_as_patient WHERE id=$pids" );
    $docdata =$wpdb->get_row("SELECT  prescription_form_details FROM wp_as_doctor WHERE doctor_email='$doctor_email'" );
     $clinicalreport= json_decode($dgdata->clinicalreport, true);
  
    if($docdata === null)
    {   $fast_line_left ='';
        $second_line_left='';
        $third_line_left='';
        $fast_line_right='';
        $second_line_right='';
        $third_line_right='';
        $image_url='';
        $footer_text='';
        
    
    
    }else{
    
        $prescription_form_details = json_decode($docdata->prescription_form_details, true);

      
        $image_url= isset($prescription_form_details['image_url']) ? '<img style=" width:100%; height:50mm;"src="'.esc_url($prescription_form_details['image_url']).'" alt="Selected Image">' : '';
        $footer_text= $prescription_form_details['footer_text'];
    }

$laststep='</div>
                
                <button class="btn btn-primary"  onclick="printContent(`prescription_print`);">Print Prescription</button>'.$newprescription.'
    </div>
    <script type="text/javascript">
                function printContent(el) {
                    var restorepage = document.body.innerHTML;
                    var printcontent = document.getElementById(el).innerHTML;
                    document.body.innerHTML = printcontent;
                    window.print();
                    document.body.innerHTML = restorepage;
                }
    // Get the current URL
    var currentURL = window.location.href;
    
    // Construct the URL for the QR code API with the current URL as data
    var qrCodeUrl = "https://qrcode.tec-it.com/API/QRCode?data=" + encodeURIComponent(currentURL);
    
    // Get the image element by its ID
    var qrCodeImage = document.getElementById("qrCodeImage");
    
    // Check if the image element is found
    if (qrCodeImage) {
        // Set the QR code URL as the src attribute of the image
        qrCodeImage.src = qrCodeUrl;
    
        // Optional: Log the updated QR code URL to the console
        console.log("Updated QR Code URL:", qrCodeUrl);
    } else {
        console.error("Image element not found");
    }
            </script>';
          
            $fulltext =' <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
              <style>
            
            *,
                    :after,
                    :before {
                        box-sizing: border-box
                    }
            
                    br {
                        clear: both;
                    }
             @media print {
                        @page {
                            size: A4;
                            /* DIN A4 standard, Europe */
                            margin-top: 5mm;
                            margin-right: 10mm;
                            margin-bottom: 5mm;
                            margin-left: 11mm;
                            background: white;
                        }
            
                        html,
                        body {
                            height: 99%;
                        }
                        .pesciptiontable{
                            width: 210mm;
                            height: 297mm;
                            margin: 0 auto;
                            margin-top: 1mm;
                            margin-bottom: 5mm;
                            margin-left: 1mm auto;
                            background: white;
                            display: block;
                            border-radius: 5px;
                            padding: 0.5in 0.5in 0.5in 0.5in;
            
                        }
                        .doc_head {display: flex !important;}    
                      }
                      @media screen {
                        .doc_head {display: flex !important;}    
                      .pesciptiontable{
                            width: 210mm;
                            height: 297mm;
                            margin-right: 1mm;
                            margin-top: 1mm;
                            margin-bottom: 2mm;
                            margin-left: 1mm ;
                            background: white;
                            display: block;
                            border-radius: 5px;
                            padding: 0.5in 0.5in 0.5in 0.5in;
            
                        }}
            
                        .doc_head {display: flex !important;}    
              </style>
              <button class="btn btn-primary ml-4"  onclick="printContent(`prescription_print`);">Print Prescription</button>'.$newprescription.'
                            <div class="entry-content">
                            <div class="pesciptiontable" id="prescription_print">
                                <div class="doc_head" style="width:100%; height:60mm;display:flex;">
                                    <div style="width:100%;">'.$image_url.'</div>
                                </div>
                                 <div class="doc_head" style="display: flex; width:100%; min-height:25mm;max-height:30mm; border-width: 1px 0px 1px 0px; border-color: black; border-style: solid;">
                                    <div  style="width:15%;">
                                        <img src="https://qrcode.tec-it.com/API/QRCode?data=https://asraful.com.bd" 
                                        alt="QR Code" id="qrCodeImage"   style="height:80px; width:80px; padding: 5px; " />
                                    </div>
                                    <div style="width:30%;">
                                        <p style="margin-left:8px"><span >Name:'.$pdata->patient_name.'
                                        <br>Address:'.$pdata->patient_address.'<br>Gender: '.$pdata->patient_gender.'</span></p>
                                    </div>
                                    <div style="width:25%;">
                                        <p style="margin-left:8px"><span>Age: '.$pdata->patient_age.'Year<br>Blood Group: '.$pdata->blood_group.' <br>Weight : '.$pdata->patient_weight.'</span></p>
                                    </div>
                                    <div style="width:30%;">
                                        <p style="margin-left:20px"><span>Date: '.$dgdata->date.' 
                                        <br>Height : '.$pdata->patient_height.' <br>Patient ID : '.$pids.'</span></p>
                                    </div>
                                </div>
                                <div class="doc_head" style="width:100%; display: flex;">
                                    <div style="width:30%; height:190mm !important;border-right:1px solid black; border-bottom:1px solid black;">
                                        <p><span style="font-size:18.0pt">C/C</span></p>
                                        <p>'.$clinicalreport['cc'].'</p>
                                        <p><span style="font-size:18.0pt">O/E</span></p>
                                        <p>'.$clinicalreport['bp'].'</p>
                                        <p>'.$clinicalreport['pulse'].'</p>
                                        <p>'.$clinicalreport['spo2'].'</p>
                                        <p>'.$clinicalreport['anaemia'].'</p>
                                        <p>'.$clinicalreport['jaubdice'].'</p>
                                        <p>'.$clinicalreport['etc'].'</p>
                                    </div>
                                    
                                    <div style="width:70%; height:190mm !important;border-bottom:1px solid black; " >
                                        <p><span style="font-size:11pt"><span style="font-family:Calibri,sans-serif"><span
                                                        style="font-size:20.0pt">R</span>x</span></span></p>
                                        '.$dgdata->medicine.'
                                    </div>
                                </div>
                                <div style="width:100%;">
                                    <div style="text-align: center;">'.$footer_text.'</div>
                                </div>
                            </div>'. $laststep;
                        
                         return $fulltext;}else{
                           echo 'No data found';
                             }
                        }                           