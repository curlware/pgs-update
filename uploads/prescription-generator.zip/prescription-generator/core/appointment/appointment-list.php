<?php 
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// Doctor dashboard shortcode
 function doctor_appointment_dashboard_shortcode() {
    ob_start();
  // Check if the user is logged in and has the manager role
  if (is_user_logged_in() && current_user_can('doctor') || current_user_can('administrator')) {
    $user_id = get_current_user_id();
   
    pgs_appointmet_list();
} elseif (is_user_logged_in() && current_user_can('assistant')) {
    $user_id = get_current_user_id();
    pgs_appointmet_list();
    // Display links based on user role
   
}

else {
    // If the user is not a manager, display an error message
    echo '<p class="error-message">You do not have permission to access this page.</p>';
}
    return ob_get_clean();
}

    function pgs_appointmet_list(){
    
        
        ?>

    <div class="row" >
        <div class="sidebar col-lg-3 col-sm-12" >
        <?php pgs_side_bar_function();?>
        </div>
        <div class="col-lg-9 col-sm-12  overflow-auto ">
            <table id="appointmentList" class="display table table-striped table-bordered" >
                <thead>
                    <tr>
                        <th>Patient Name</th>
                        <th>Patient Id</th>
                        <th>Mobile</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Daily Serial</th>
                        <th>Doctor Name</th>
                        <th>Status</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <?php 
                        global $wpdb;
                        $appointments_data = $wpdb->get_results("SELECT * FROM wp_as_appointments");
                        if (is_user_logged_in() && current_user_can('doctor') || current_user_can('administrator')) {
                            $user_id = get_current_user_id();
                           
                            global $wpdb;
                            $appointments_data = $wpdb->get_results("SELECT * FROM wp_as_appointments WHERE doctor_id = '$user_id'");
                        
                        
                            foreach ($appointments_data as $data) {
                                $new_pescription_url= 'new-prescription/?patientid='.$data->patient_id;
    
                                echo "<tr><td>{$data->patient_name}</td><td>{$data->patient_id}</td><td>{$data->patient_mobile}</td><td>{$data->appointment_date}</td><td>{$data->appointment_time}</td><td>{$data->appointment_daily_id}</td><td>{$data->doctor_name}</td><td>{$data->appoint_status}</td><td><a href='".site_url($new_pescription_url)."'>New prescription</a></td></tr>";
                            }
                        } elseif (is_user_logged_in() && current_user_can('assistant')) {
                            $user_id = get_current_user_id();
                            global $wpdb;
                            $doctor_details = $wpdb->get_row("SELECT doctor_id FROM wp_as_doctor WHERE assistant_id = '$user_id'");
                          if (isset($doctor_details->doctor_id) && $doctor_details->doctor_id > 0 ) {
                           
                         
                            $appointments_data = $wpdb->get_results("SELECT * FROM wp_as_appointments WHERE doctor_id = '$doctor_details->doctor_id'");

                            
                        foreach ($appointments_data as $data) {
                            $new_pescription_url= 'new-prescription/?patientid='.$data->patient_id;

                            echo "<tr><td>{$data->patient_name}</td><td>{$data->patient_id}</td><td>{$data->patient_mobile}</td><td>{$data->appointment_date}</td><td>{$data->appointment_time}</td><td>{$data->appointment_daily_id}</td><td>{$data->doctor_name}</td><td>{$data->appoint_status}</td><td><a href='".site_url($new_pescription_url)."'>New prescription</a></td></tr>";
                        }
                    }else{
                        echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">You are not permited.
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>';
                    }

                        }else{
                            echo "You are not Permited";
                        }
                        
                        ?>
                <tfoot>
                    <tr>
                        <th>Patient Name</th>
                        <th>Patient Id</th>
                        <th>Mobile</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Daily Serial</th>
                        <th>Doctor Name</th>
                        <th>Status</th>
                        <th>Details</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
    <script>new DataTable('#appointmentList', {
    
    buttons: [
        'copy', 'excel', 'pdf'
    ],

    });</script>



    <?php
    } 