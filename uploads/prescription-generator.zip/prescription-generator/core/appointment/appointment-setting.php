<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// Doctor appoint setting shortcode
function doctor_appointment_setting_shortcode() {
    ob_start();
  // Check if the user is logged in and has the manager role
  if (is_user_logged_in() && current_user_can('doctor') || current_user_can('administrator')) {
    $user_id = get_current_user_id();
   
    doctor_appointment_setting();
} elseif (is_user_logged_in() && current_user_can('assistant')) {
    $user_id = get_current_user_id();
    echo '<p class="error-message">You do not have permission to access this page.</p>';
    // Display links based on user role
   
}

else {
    // If the user is not a manager, display an error message
    echo '<p class="error-message">You do not have permission to access this page.</p>';
}
    return ob_get_clean();
}


function doctor_appointment_setting(){ ?>
<div class="row" >
    <div class="sidebar col-lg-3 col-sm-12" >
        <?php pgs_side_bar_function();?>
    </div>
    
    <div class="col-lg-9 col-sm-12">  
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Appointment Schedule Information </h4>
            </div>
            <div class="card-body">
                        
                <div id="prescription-form-submenu-form"class="basic-form">
                
                    <form id="dateDayTimeForm">
                        <input type="hidden" value="<?php _e(get_current_user_id());?>" name="doctor_id" id="doctorId">
                        <label for="day">Day:</label>
                        <select id="day" name="day"  class="form-control form-select">
                            <option value="">Select Day</option>
                        </select>

                        <label for="stime">Start Time:</label>
                        <select id="stime" name="time"  class="form-control form-select">
                            <option value="">Select Time</option>
                        </select>
                        <label for="etime">End Time:</label>
                        <select id="etime" name="time"  class="form-control form-select">
                            <option value="">Select Time</option>
                        </select>

                        <button type="submit" class="btn btn-primary" >Add</button>
                    </form>
                </div>
                    <style>#appointmentTime td{
                        white-space: nowrap;
                    }</style>
                <div id="prescription-form-submenu-content"class="basic-form overflow-auto ">
                    <br>
                    <div class="table-responsive">
                    <table id="appointmentTime" class="table table-striped table-bordered" >
                    <tbody></tbody> 
                    </table> 
                    </div>  
                </div>   
            </div>
        </div>
    </div>   
</div>

<script>

    jQuery(document).ready(function($) {
        // Populate days dropdown on page load
        var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        days.forEach(function(day) {
            $('#day').append('<option value="' + day + '">' + day + '</option>');
        });

        // Populate times dropdown on page load
        var times = ['8:00 AM', '9:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM', '5:00 PM', '6:00 PM', '9:00 PM'];
        times.forEach(function(time) {
            $('#stime').append('<option value="' + time + '">' + time + '</option>');
            $('#etime').append('<option value="' + time + '">' + time + '</option>');
        });

        
        var doctorId = $('#doctorId').val();
        // Handle form submission for date, day, time
        $('#dateDayTimeForm').submit(function(event) {
            event.preventDefault();
            // Retrieve values from the form
            
            var selectedDay = $('#day').val();
            var startTime = $('#stime').val();
            var endTime = $('#etime').val();
            $.ajax({
            url: ajax_object.ajax_url,
            type: 'POST',
            data: { 
                action: 'add_doctor_appoint_time',
                pgs_nonce: ajax_object.pgs_nonce, // Pass the nonce to the server
                doctor_id: doctorId,
                appointment_day: selectedDay,
                appointment_time: startTime + ' - ' + endTime,
            },
            success: function(data) {
                // Handle the success response and populate the table
                alert(data);
                reloadAppointmentTable();
            },
            error: function(error) {
                // Handle errors
                console.log(error.responseText);
            }
        });

        });


        $(document).ready(function() {
            // Call the function when the page initially loads
            reloadAppointmentTable();
        });
        
        // Include this in your JavaScript file or script tag
        function reloadAppointmentTable(){
                $.ajax({
                    url: ajax_object.ajax_url,
                    type: 'POST',
                    data: { 
                        action: 'list_doctor_appoint_time',
                        pgs_nonce: ajax_object.pgs_nonce, // Pass the nonce to the server
                        doctor_id: doctorId,
                    },
                    success: function(data) {
                        // Handle the success response and populate the table
                        populateAppointmentTable(data);
                    },
                    error: function(error) {
                        // Handle errors
                        console.log(error.responseText);
                    }
                });
        }

        function populateAppointmentTable(schedule) {
            var table = $('#appointmentTime');

            // Clear previous table content
            table.find('tr').remove();

            // Iterate through the days and populate the table
            $.each(schedule, function(day, times) {
                var row = $('<tr>');
                row.append($('<th>').text(day));

                // Append appointment times for each day
                $.each(times, function(index, timeData) {
                    var timeId = timeData.id; // Use the id from the database
           // Use the appointment time from the database
            var iconElement = $(' <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 0 512 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path fill="#ff0000" d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8zm121.6 313.1c4.7 4.7 4.7 12.3 0 17L338 377.6c-4.7 4.7-12.3 4.7-17 0L256 312l-65.1 65.6c-4.7 4.7-12.3 4.7-17 0L134.4 338c-4.7-4.7-4.7-12.3 0-17l65.6-65-65.6-65.1c-4.7-4.7-4.7-12.3 0-17l39.6-39.6c4.7-4.7 12.3-4.7 17 0l65 65.7 65.1-65.6c4.7-4.7 12.3-4.7 17 0l39.6 39.6c4.7 4.7 4.7 12.3 0 17L312 256l65.6 65.1z"/></svg>');
            // var time = timeData.appointment_time; 
            // row.append($('<td>').text(time).attr('data-timeid', timeId));
                
            var time = timeData.appointment_time;
            var tdElement = $('<td>').attr('data-timeid', timeId);


            // Set the text content of the tdElement (including the icon)
            tdElement.append(document.createTextNode(time + '  '));

            // Append the iconElement to the tdElement
            tdElement.append(iconElement);

            // Append the tdElement to the row
            row.append(tdElement);

                });

                table.append(row);
            });
        }

            // Include this in your JavaScript file or script tag

            // Click event handler for the table cell

            $('#appointmentTime').on('click', 'td', function() {
                // Get the data-time-id attribute value
                var dataTimeId = $(this).data('timeid');

                // Show a confirmation dialog
                var confirmation = confirm('Are you sure you want to delete this appointment?');

                if (confirmation) {
                    // If the user confirms, send an AJAX request to delete the record
                    deleteAppointment(dataTimeId);
                } else {
                    // If the user cancels, you can handle it accordingly
                    alert('Deletion canceled.');
                }
            });
  
        // Function to send an AJAX request to delete the appointment
    function deleteAppointment(dataTimeId) {
        // Assuming doctorId is available
        $.ajax({
            url: ajax_object.ajax_url,
            type: 'POST',
            data: {
                action: 'delete_appointment_callback',
                doctor_id: doctorId,
                data_time_id: dataTimeId,
                pgs_nonce: ajax_object.pgs_nonce, // Pass the nonce to the server
            },
            success: function(response) {
                // Handle the success response
                alert('Appointment deleted successfully!');
                reloadAppointmentTable();
                // Optionally, you can update the UI or perform any other actions
            },
            error: function(error) {
                // Handle errors
                console.log(error.responseText);
            }
        });
    }


  });


</script>
<?php
} 




?>