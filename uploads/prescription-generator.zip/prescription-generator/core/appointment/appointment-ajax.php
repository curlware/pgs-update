<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// check_doctor_appoint_time List
add_action('wp_ajax_list_doctor_appoint_time', 'list_doctor_appoint_time');
add_action('wp_ajax_nopriv_list_doctor_appoint_time', 'list_doctor_appoint_time');
function list_doctor_appoint_time(){
    $doctor_id = isset($_POST['doctor_id']) ? sanitize_text_field($_POST['doctor_id']) : '';
   
    
    if (isset($_POST['pgs_nonce']) && wp_verify_nonce($_POST['pgs_nonce'], 'pgs_nonce_action')) {
    
        // Mobile number exists, load the patient list form
        global $wpdb;
        
        $search_results = $wpdb->get_results(
            $wpdb->prepare("SELECT id, appointment_day, appointment_time FROM wp_as_schedule WHERE doctor_id = %d", $doctor_id)
        );

        // Prepare the response
        $response = array();
        foreach ($search_results as $result) {
            $response[$result->appointment_day][] = ['appointment_time' => $result->appointment_time, 'id' => $result->id ];
        }

        wp_send_json($response);


    }else {
        // Nonce verification failed
        wp_send_json_error('Nonce verification failed.');
    }


}
// add_doctor_appoint_time
add_action('wp_ajax_add_doctor_appoint_time', 'add_doctor_appoint_time');
add_action('wp_ajax_nopriv_add_doctor_appoint_time', 'add_doctor_appoint_time');
function add_doctor_appoint_time(){

    $doctor_id = isset($_POST['doctor_id']) ? sanitize_text_field($_POST['doctor_id']) : '';
    $appointment_day = isset($_POST['appointment_day']) ? sanitize_text_field($_POST['appointment_day']) : '';
    $appointment_time = isset($_POST['appointment_time']) ? sanitize_text_field($_POST['appointment_time']) : '';

    if (isset($_POST['pgs_nonce']) && wp_verify_nonce($_POST['pgs_nonce'], 'pgs_nonce_action')) {
    
        // Mobile number exists, load the patient list form
        global $wpdb;
        $insert_data = array(
            'doctor_id' => $doctor_id,
            'appointment_day' => $appointment_day,
            'appointment_time' => $appointment_time,
        );
   $wpdb->insert('wp_as_schedule', $insert_data);
   $response = 'insert success';
   wp_send_json($response);
    }else {
        // Nonce verification failed
        wp_send_json_error('Nonce verification failed.');
    }
}
// Add this code to your theme's functions.php file or in a custom plugin

// AJAX handler for deleting the appointment
add_action('wp_ajax_delete_appointment_callback', 'delete_appointment_callback');
add_action('wp_ajax_nopriv_delete_appointment_callback', 'delete_appointment_callback');

function delete_appointment_callback() {
    // Verify nonce for security
    if (isset($_POST['pgs_nonce']) && wp_verify_nonce($_POST['pgs_nonce'], 'pgs_nonce_action')) {
        global $wpdb;

        $doctor_id = isset($_POST['doctor_id']) ? intval($_POST['doctor_id']) : 0;
        $data_time_id = isset($_POST['data_time_id']) ? intval($_POST['data_time_id']) : 0;

        // Perform the deletion from the wp_as_schedule table
        $result = $wpdb->delete(
            'wp_as_schedule',
            array(
                'doctor_id' => $doctor_id,
                'id' => $data_time_id,
            ),
            array('%d', '%d')
        );

        if ($result !== false) {
            // If deletion is successful, send a success response
            wp_send_json_success('Appointment deleted successfully!');
        } else {
            // If deletion fails, send an error response
            wp_send_json_error('Error deleting appointment.');
        }
    } else {
        // Nonce verification failed
        wp_send_json_error('Nonce verification failed.');
    }

    // Always exit after processing AJAX
    wp_die();
}


//start appointment prosses

// get_phone_number_form 
add_action('wp_ajax_get_phone_number_form', 'get_phone_number_form');
add_action('wp_ajax_nopriv_get_phone_number_form', 'get_phone_number_form');

function get_phone_number_form() {
    $doctor_id = isset($_POST['doctor_id']) ? sanitize_text_field($_POST['doctor_id']) : '';
    $doctor_name = isset($_POST['doctor_name']) ? sanitize_text_field($_POST['doctor_name']) : '';
     // Mobile number exists, load the patient list form
     global $wpdb;
     $all_days_name = $wpdb->get_results(
         $wpdb->prepare( "SELECT appointment_day FROM wp_as_schedule WHERE doctor_id = %d", $doctor_id )
     );
     // Extract unique day names
        $unique_days = array_unique(array_column($all_days_name, 'appointment_day'));

        echo '
        <form id="phoneNumberForm" class="signup-form">
            <div class="form-group mb-2">
                <label for="mobileNumber">Enter Mobile Number:</label>
                <input type="number" id="mobileNumber" name="mobileNumber" class="form-control" required>
            </div>
            <div class="form-group mb-2">
                <label for="day">Day:</label>
                <select id="day" name="day" class="form-control"> 
                     <option value="">Select Day</option>';
                   
                    if (isset($unique_days) && !empty($unique_days)) {
                        foreach ($unique_days as $day) {
                            echo '<option value="' . $day . '">' . $day . '</option>';
                        }
                    }     
                    echo '</select>
            </div>
            <div class="form-group mb-2">
                <label for="datepicker">Select Date:</label>
                <input type="text" id="datepicker" name="date" class="form-control">
            </div>
            <div class="form-group mb-2">
                <label for="time" >Time:</label>
                <select id="time" name="time" class="form-control" disabled>
            </div>
           
            <div class="form-group mb-2">
                <input type="hidden" id="doctorId" name="doctor_id" value="'.$doctor_id.'">
                <input type="hidden" id="doctorName" name="doctor_name" value="'.$doctor_name.'">
                <input type="hidden" id="pgsnonce" name="pgsnonce" value="'. wp_create_nonce('pgs_nonce').'">
                
                <button type="submit" class="form-control btn btn-primary rounded submit mt-4 px-3">Appoint</button>
            </div>
            
        </form>
        ';
         ?><script>
          jQuery(document).ready(function($) {
            // Initialize the jQuery UI Datepicker
            $("#datepicker").datepicker({
                dateFormat: 'yy-mm-dd',
                minDate: 0, // Disable previous dates from today
                
                beforeShowDay: function(date) {
                    var dayToEnable = $('#day').val();
                    if (dayToEnable !== '') {
                        return [date.getDay() == dayToEnableIndex(dayToEnable)];
                    } else {
                        return [false, ''];
                    }
                },
                onSelect: function(selectedDate) {
                    // Fetch and populate times based on selected date and day
                    var selectedDay = $('#day').val();
                    var doctorId = $('#doctorId').val();
                    var pgsnonce = $('#pgsnonce').val();
                    if (selectedDay !== '') {
                        $.ajax({
                            url:ajax_object.ajax_url, // Update with your PHP endpoint
                            type: 'POST',
                            data: { 
                                action: 'check_doctor_appoint_time',
                                doctor_id: doctorId, 
                                appointment_day: selectedDay,
                                pgs_nonce: pgsnonce,
                             },
                             success: function (data) {
                                console.log(data);
                                    var schedule =  data;

                                    // Select the time dropdown by its ID
                                    var timeDropdown = $('#time');

                                    // Empty the existing options and enable the dropdown
                                    timeDropdown.empty().prop('disabled', false);

                                    // Add a default option
                                    timeDropdown.append('<option value="">Select Time</option>');

                                    // Populate the dropdown with retrieved schedule
                                    schedule.forEach(option => {
                                        $('<option>').val(option.appointment_time).text(option.appointment_time).appendTo(timeDropdown);
                                        });
                                }
                        });
                    }
                }
            });
    
            function dayToEnableIndex(day) {
                var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                return days.indexOf(day);
            }
        });
          </script><?php
    die();
}


//check_mobile_availability
add_action('wp_ajax_check_mobile_availability', 'check_mobile_availability');
add_action('wp_ajax_nopriv_check_mobile_availability', 'check_mobile_availability');

function check_mobile_availability() {
    $mobile_number = isset($_POST['mobile_number']) ? sanitize_text_field($_POST['mobile_number']) : '';
    $doctor_id = isset($_POST['doctor_id']) ? sanitize_text_field($_POST['doctor_id']) : '';
    $doctor_name = isset($_POST['doctor_name']) ? sanitize_text_field($_POST['doctor_name']) : '';
    $doctor_time = isset($_POST['doctor_time']) ? sanitize_text_field($_POST['doctor_time']) : '';
    $doctor_date = isset($_POST['doctor_date']) ? sanitize_text_field($_POST['doctor_date']) : '';
    $pgs_nonce = isset($_POST['pgs_nonce']) ? sanitize_text_field($_POST['pgs_nonce']) : '';
    // Verify the nonce
    if (!wp_verify_nonce($pgs_nonce, 'pgs_nonce')) {
        die('Are you cheat?');
    }
    global $wpdb;
    $patient_exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM wp_as_patient WHERE patient_mobile = %s", $mobile_number));

    if ($patient_exists > 0) {
        // Mobile number exists, load the patient list form
        global $wpdb;
        $search_results = $wpdb->get_results(
            $wpdb->prepare( "SELECT id, patient_name FROM wp_as_patient WHERE patient_mobile = %s", $mobile_number )
        );
        ?> 
        <table id="patient-datatable" class="display table">
            <thead>
                <tr>
                    <th>Patient Name</th>
                    <th>Patient ID</th>                  
                </tr>
            </thead>
            <tbody>
                <?php
                // Display search results
                if (isset($search_results) && !empty($search_results)) {
                    foreach ($search_results as $result) {
                        echo "<tr class='appointconfirm' 
                            data-doctor-id='".$doctor_id."' 
                            data-doctor-date='".$doctor_date."' 
                            data-doctor-time='".$doctor_time."' 
                            data-doctor-name='".$doctor_name."'
                            data-patient-id= '{$result->id}' 
                            data-patient-name= '{$result->patient_name}' 
                            data-patient-mobile= '{$mobile_number}'>
                        <td>{$result->patient_name}</td><td>{$result->id}</td></tr>";
                    }
                } 
                ?>
            </tbody>
        </table>
        <?php
    } else {

        $mobile_number = isset($_POST['mobile_number']) ? sanitize_text_field($_POST['mobile_number']) : '';
        $doctor_id = isset($_POST['doctor_id']) ? sanitize_text_field($_POST['doctor_id']) : '';
        $doctor_name = isset($_POST['doctor_name']) ? sanitize_text_field($_POST['doctor_name']) : '';
        $doctor_time = isset($_POST['doctor_time']) ? sanitize_text_field($_POST['doctor_time']) : '';
        $doctor_date = isset($_POST['doctor_date']) ? sanitize_text_field($_POST['doctor_date']) : '';
        // Mobile number doesn't exist, load another form
       

        ?>  <div class="basic-form">
        <form id="newappointconfirm">

<?php echo '<input type="hidden" id="doctorId" name="doctor_id" value="'.$doctor_id.'">
            <input type="hidden" id="doctorName" name="doctor_name" value="'.$doctor_name.'">
            <input type="hidden" id="doctorDate" name="doctor_date" value="'.$doctor_date.'">
            <input type="hidden" id="doctorTime" name="doctor_time" value="'.$doctor_time.'">'; ?>


            <div class="row">
                <div class="col-xl-6">
                    <div class="form-group">
                    <label>Patient Full Name : </label>
                        <input name="patient_name"type="text" id="patientName" value="" class="form-control" placeholder="Patient Full Name"required>
                    </div>
                    <div class="form-group">
                    <label>Patient Mobile Number : </label>
                        <input name="patient_mobile" id="patientMobile" value="<?php echo $mobile_number; ?>" type="text" class="form-control" placeholder="Mobile No." readonly>
                    </div>
                    <div class="form-group">
                        
                        <label>Patient Age : </label>
                        <input name="patient_age" id="patientAge" type="text" class="form-control" placeholder="Age" required>
                    
                    </div>
                    <div class="form-group">
                    <label>Patient Address : </label>
                        <textarea class="form-control" id="patientAddress" name="patient_address" placeholder="Address" rows="4" ></textarea>
                    </div>
                </div>
                <div class="col-xl-6">                   
                    <div class="form-group">
                    <label>Marital status : </label>
                        <select name="patient_marital_status" id="patientMaritalstatus" class="form-control form-select">
                            <option> Marital status </option>
                            <option value="Married">Married</option>
                            <option value="Unmarried">Unmarried</option>
                        </select>
                    </div>
                    <div class="form-group">
                    <label>Gender : </label>
                        <select name="patient_gender" id="patientGender" class="form-control form-select" required>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>
                    <div class="form-group">
                    <label>Blood Group : </label>
                        <select name="blood_group" id="patientBloodGroup" class="form-control form-select">
                            <option value="">Blood Group</option>
                            <option value="A+">A+</option>
                            <option value="A-">A-</option>
                            <option value="B+">B+</option>
                            <option value="B-">B-</option>
                            <option value="O+">O+</option>
                            <option value="O-">O-</option>
                            <option value="AB+">AB+</option>
                            <option value="AB-">AB-</option>
                        </select>
                    </div>
                    <div class="form-group row">
                        <div class="col-lg-12">
                        <label>Patient weight : </label>
                            <input name="patient_weight" id="patientWeight" type="text" class="form-control"  placeholder="Patient Weight">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-lg-12">
                        <label>Patient Height : </label>
                            <input name="patient_height" id="patientHeight" type="text" class="form-control" placeholder="Patient Height">
                        </div>
                    </div>
                </div>
            </div>            
            <div class="row">
                <div class="col-xl-6">
                    
                </div>
                <div class="col-xl-6">
                    
                    <div class="form-group text-right">
                        <button type="submit" name="newappointconfirm" class="btn btn-primary float-end">Confirm</button>
                    </div>
                </div>
            </div>
        </form>
    </div>  
    <?php
    }

    die();
}


// check_doctor_appoint_time
add_action('wp_ajax_check_doctor_appoint_time', 'check_doctor_appoint_time');
add_action('wp_ajax_nopriv_check_doctor_appoint_time', 'check_doctor_appoint_time');

function check_doctor_appoint_time(){
    $doctor_id = isset($_POST['doctor_id']) ? sanitize_text_field($_POST['doctor_id']) : '';
    $appointment_day = isset($_POST['appointment_day']) ? sanitize_text_field($_POST['appointment_day']) : '';

    if (isset($_POST['pgs_nonce']) && wp_verify_nonce($_POST['pgs_nonce'], 'pgs_nonce')) {
    
        // Mobile number exists, load the patient list form
        global $wpdb;
        $search_results = $wpdb->get_results(
            $wpdb->prepare( "SELECT id, appointment_time FROM wp_as_schedule WHERE doctor_id = %d AND appointment_day = %s", $doctor_id, $appointment_day, )
        );

        // Initialize an empty array to store the actual schedule
            $schedule = array();

            // Check if there are results from the database query
            if ($search_results) {
                // Iterate through the results and format them as needed
                foreach ($search_results as $result) {
                    $schedule[] = array(
                        'appointment_time' => $result->appointment_time,
                        //'id' => $result->id,
                        // Add more fields as needed
                    );
                    //echo '<option value="'.$result->appointment_time.'">'.$result->appointment_time.'</option>';
                }
            }
            // Send the JSON-encoded response back to the client
            wp_send_json($schedule);
    } else {
        // Nonce verification failed
        wp_send_json_error('Nonce verification failed.');
    }
die();
}


//submit_confirm_appointment for old patient
add_action('wp_ajax_submit_confirm_appointment', 'submit_confirm_appointment');
add_action('wp_ajax_nopriv_submit_confirm_appointment', 'submit_confirm_appointment');

 function submit_confirm_appointment() {
    $doctor_id = isset($_POST['doctor_id']) ? sanitize_text_field($_POST['doctor_id']) : '';
    $doctor_name = isset($_POST['doctor_name']) ? sanitize_text_field($_POST['doctor_name']) : '';
    $doctor_time = isset($_POST['doctor_time']) ? sanitize_text_field($_POST['doctor_time']) : '';
    $doctor_date = isset($_POST['doctor_date']) ? sanitize_text_field($_POST['doctor_date']) : '';
    $patient_id = isset($_POST['patient_id']) ? sanitize_text_field($_POST['patient_id']) : '';
    $patient_name = isset($_POST['patient_name']) ? sanitize_text_field($_POST['patient_name']) : '';
    $patient_mobile = isset($_POST['patient_mobile']) ? sanitize_text_field($_POST['patient_mobile']) : '';
    global $wpdb;
    $appointment_daily_id = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM wp_as_appointments WHERE appointment_date = %s AND doctor_id = %d", $doctor_date, $doctor_id));
    $appointment_daily_id_new = $appointment_daily_id + 1 ;
    $insert_appoint = $wpdb->insert(
        'wp_as_appointments',
        array(
        'doctor_id'      => $doctor_id ,
        'doctor_name'    => $doctor_name,
        'patient_id'     => $patient_id ,
        'patient_name'   => $patient_name ,
        'patient_mobile' => $patient_mobile ,
        'appoint_status' => 'pending',
        'appointment_date' => $doctor_date ,
        'appointment_time' => $doctor_time ,
        'appointment_daily_id' => $appointment_daily_id_new ,
        ),
        array(
        '%d',    
        '%s',
        '%d',
        '%s',
        '%d',
        '%s',
        '%s',
        '%s',
        '%d',
        )
        );

   echo '<div class="alert alert-success" role="alert">
            <h4 class="alert-heading">Thanks for the appointment!</h4>
            <p>Patient Id : <b>'.$patient_id.'</b></p>
            <p>Patient Name : <b>'.$patient_name.'</b></p>
            <p>Appoint Number : <b>'.$appointment_daily_id_new.'</b></p>
            <p>Appoint Date and Time : <b>'.$doctor_date.' => '.$doctor_time.'</b></p>               
            <hr>
            <p class="mb-0">Doctor Name: <b>'.$doctor_name.' </b></p>
            <button type="button" class="btn btn-primary" id="saveScreenshotBtn">Save Screenshot</button>
        </div>';
    die();
}

//submit_confirm_newappointment for new patient
add_action('wp_ajax_submit_confirm_newappointment', 'submit_confirm_newappointment');
add_action('wp_ajax_nopriv_submit_confirm_newappointment', 'submit_confirm_newappointment');
function submit_confirm_newappointment(){

    $doctor_id = isset($_POST['doctor_id']) ? sanitize_text_field($_POST['doctor_id']) : '';
    $doctor_name = isset($_POST['doctor_name']) ? sanitize_text_field($_POST['doctor_name']) : '';
    $doctor_time = isset($_POST['doctor_time']) ? sanitize_text_field($_POST['doctor_time']) : '';
    $doctor_date = isset($_POST['doctor_date']) ? sanitize_text_field($_POST['doctor_date']) : '';
    $patient_name = isset($_POST['patient_name']) ? sanitize_text_field($_POST['patient_name']) : '';
    $patient_mobile = isset($_POST['patient_mobile']) ? sanitize_text_field($_POST['patient_mobile']) : '';
    $patient_age = isset($_POST['patient_age']) ? sanitize_text_field($_POST['patient_age']) : '';
    $patient_address = isset($_POST['patient_address']) ? sanitize_text_field($_POST['patient_address']) : '';
    $patient_marital_status = isset($_POST['patient_marital_status']) ? sanitize_text_field($_POST['patient_marital_status']) : '';
    $patient_gender = isset($_POST['patient_gender']) ? sanitize_text_field($_POST['patient_gender']) : '';
    $patient_blood = isset($_POST['patient_blood']) ? sanitize_text_field($_POST['patient_blood']) : '';
    $patient_weight = isset($_POST['patient_weight']) ? sanitize_text_field($_POST['patient_weight']) : '';
    $patient_height = isset($_POST['patient_height']) ? sanitize_text_field($_POST['patient_height']) : '';
    global $wpdb;
    $wpdb->insert(
        'wp_as_patient',
        array(
            'patient_name' => $patient_name,
            'patient_mobile' => $patient_mobile,
            'patient_age' => $patient_age,
            'patient_marital_status' => $patient_marital_status,
            'patient_gender' => $patient_gender,
            'blood_group' => $patient_blood,
            'patient_weight' => $patient_weight,
            'patient_height' => $patient_height,
            'patient_address' =>  $patient_address ,
            
        ),
        array(
        '%s',
        '%d',    
        '%d',
        '%s',
        '%s',
        '%s',
        '%d',
        '%s',
        '%s',
        )
        );
        $last_insert_id = $wpdb->insert_id;

    global $wpdb;
    $appointment_daily_id = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM wp_as_appointments WHERE appointment_date = %s AND doctor_id = %d", $doctor_date, $doctor_id));
    $appointment_daily_id_new = $appointment_daily_id + 1 ;
    $insert_appoint = $wpdb->insert(
        'wp_as_appointments',
        array(
        'doctor_id'      => $doctor_id ,
        'doctor_name'    => $doctor_name ,
        'patient_id'     => $last_insert_id ,
        'patient_name'   => $patient_name ,
        'patient_mobile' => $patient_mobile ,
        'appoint_status' => 'pending',
        'appointment_date' => $doctor_date ,
        'appointment_time' => $doctor_time ,
        'appointment_daily_id' => $appointment_daily_id_new ,

        ),
        array(
        '%d',    
        '%s',
        '%d',
        '%s',
        '%d',
        '%s',
        '%s',
        '%s',
        '%d',
        )
        );


    echo '<div class="alert alert-success" role="alert">
    <h4 class="alert-heading">Thanks for the appointment!</h4>
    <p>Patient Id : <b>'.$last_insert_id.'</b></p>
    <p>Patient Name : <b>'.$patient_name.'</b></p>
    <p>Appoint Number : <b>'.$appointment_daily_id_new.'</b></p>
    <p>Appoint Date and Time : <b>'.$doctor_date.' => '.$doctor_time.'</b></p>
    <hr>
    <p class="mb-0">Doctor Name: <b>'.$doctor_name.' </b></p>
    <button type="button" class="btn btn-primary" id="saveScreenshotBtn">Save Screenshot</button>
</div>';
die();
}
