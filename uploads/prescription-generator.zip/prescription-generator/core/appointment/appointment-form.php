<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function  appointment_form_shortcode (){
global $wpdb; 
    $result = $wpdb->get_results("SELECT * FROM wp_as_doctor");
?> <div class="section">
    <div class="row text-center">

  <?php  
    foreach ( $result as $data ) {
        if ( $data->appoint_status === 'on' ){$appointbtn = '<button class="showFormBtn btn btn-primary"  data-doctor-id="'.$data->doctor_id.'"  data-doctor-name="'.$data->doctor_name.'" data-toggle="modal" data-target="#exampleModal">Get a appoint</button>';}else{$appointbtn = '';} 
     echo '<div class="col-xl-4 col-sm-6 mb-5">
              <div class="bg-white rounded shadow-sm py-5 px-4">
                <img src="'.$data->doctor_profile_image_url.'" alt="'.$data->doctor_name.'" width="150" class="img-fluid rounded-circle mb-3 img-thumbnail shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">'.$data->doctor_name.'</h5>
                    <p class="card-text">'.$data->doctor_degree.'</p>
                    <p class="card-text">'.$data->doctor_specialist.'</p>
                    <p class="card-text">'.$data->doctor_address.'</p>
                    <p class="card-text">'.$data->doctor_appoint_details.'</p>
                    '.$appointbtn.'
                </div>
            </div>
         </div>';

    }?> </div>
    </div>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content"  id="save-modal">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Appointment Form</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="formContainer">
        <!-- Hare load all form -->
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
       
      </div>
    </div>
  </div>
</div>  <script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>
<script>
   jQuery(document).ready(function($) {
  // Use event delegation for dynamically loaded content
  $(document).on('click', '#saveScreenshotBtn', function() {
    // Use html2canvas to capture the screenshot
    html2canvas($('#save-modal')[0]).then(function(canvas) {
      // Convert the canvas to a data URL
      var screenshotDataUrl = canvas.toDataURL('image/png');

      // Create a link and trigger a download
      var downloadLink = document.createElement('a');
      downloadLink.href = screenshotDataUrl;
      downloadLink.download = 'screenshot.png';
      downloadLink.click();
    });
  });
});

</script>

</body>
</html>

<?php
}


