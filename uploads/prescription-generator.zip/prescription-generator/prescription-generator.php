<?php
/*
Plugin Name: Prescription Generator
Description: Generate and print prescriptions in WordPress.
Version: 1.0
Requires PHP: 7.0
Requires at least: 5.0
Author: CurlWare
Author URI: https://curlware.com/
Plugin URI: https://curlware.com/
Text Domain: asprescription
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */

require_once ( plugin_dir_path( __FILE__ ).'core/plugin-activation.php' );
register_activation_hook(__FILE__, 'pgs_prescription_form_activation');
require_once ( plugin_dir_path( __FILE__ ).'plugin-update.php' );
require_once ( plugin_dir_path( __FILE__ ).'core/presciption-shortcode.php' );
require_once ( plugin_dir_path( __FILE__ ).'core/prescription-setting.php');
require_once ( plugin_dir_path( __FILE__ ).'core/form-hendeller.php' );
require_once ( plugin_dir_path( __FILE__ ).'core/patient-list.php' );
require_once ( plugin_dir_path( __FILE__ ).'core/patient-add.php' );
require_once ( plugin_dir_path( __FILE__ ).'core/pgs-profile.php' );
require_once ( plugin_dir_path( __FILE__ ).'core/sidebar-view.php' );
require_once ( plugin_dir_path( __FILE__ ).'core/prescription-list.php' );
require_once ( plugin_dir_path( __FILE__ ).'core/print-handeler.php' );
require_once ( plugin_dir_path( __FILE__ ).'core/view/doctor-dashboard.php' );
require_once ( plugin_dir_path( __FILE__ ).'core/view/assistant-dashboard.php' );
require_once ( plugin_dir_path( __FILE__ ).'core/appointment/appointment-form.php' );
require_once ( plugin_dir_path( __FILE__ ).'core/appointment/appointment-list.php' );
require_once ( plugin_dir_path( __FILE__ ).'core/appointment/appointment-setting.php' );
require_once ( plugin_dir_path( __FILE__ ).'core/appointment/appointment-ajax.php' );

function pgs_enqueue_admin_scripts() {
    wp_enqueue_script('jquery');
    wp_enqueue_media();
    wp_register_script('prescriptionjs',  plugins_url( 'assets/js/script.js', __FILE__ ), array('jquery'), '1.0', true);
    wp_enqueue_script('prescriptionjs');
     // Check if the current page is the 'new-prescription' page
     if (is_page('new-prescription')) {
        wp_register_script('datajs',  plugins_url( 'assets/js/dragdata.js', __FILE__ ), '1.0', true);
        wp_enqueue_script('datajs');
    }
    wp_register_script('dataTablesjs',  plugins_url( 'assets/js/jquery.dataTables.min.js', __FILE__ ), '4.5', true);
    wp_enqueue_script('dataTablesjs');
    wp_register_script('bootstrap.minjs',  plugins_url( 'assets/js/bootstrap.min.js', __FILE__ ), '4.5.2', true);
    wp_enqueue_script('bootstrap.minjs');
    wp_enqueue_style('pgs-css', plugins_url( 'assets/css/pgs.style.css', __FILE__), '1.0');
    wp_enqueue_style('bootstrap-css', plugins_url( 'assets/css/bootstrap.min.css', __FILE__), '4.5.2');
    wp_enqueue_style('datatable-css', plugins_url( 'assets/css/jquery.dataTables.min.css', __FILE__), '4.5.2');
    wp_enqueue_style('datepicker-css', plugins_url( 'assets/css/jquery-ui.css', __FILE__), '1.13.2');
    wp_register_script('datepickerjs',  plugins_url( 'assets/js/jquery-ui.js', __FILE__ ), array('jquery'), '1.13.2', true);
    wp_enqueue_script('datepickerjs', 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
    wp_enqueue_script('pgs-ajax', plugins_url( 'assets/js/pgs.ajax.js', __FILE__), array('jquery'), '1.0', true);
    wp_localize_script('pgs-ajax', 'ajax_object', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'pgs_nonce' => wp_create_nonce('pgs_nonce_action')));
   }

add_action('wp_enqueue_scripts', 'pgs_enqueue_admin_scripts');

function pgs_pharmaceutical_menu_page() {
    add_menu_page(
        'Prescription Setting',
        'Prescription Setting',
        'manage_options',
        'prescription-setting',
        'pgs_prescription_form_setting',
        'dashicons-editor-paste-word',
        6
    );
}

add_action('admin_menu', 'pgs_pharmaceutical_menu_page');

add_action( 'init', 'pgs_prescription_form_submission' );


?>
